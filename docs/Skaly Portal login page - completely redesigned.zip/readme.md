# Skaly Business Portal — Design System

The **Skaly Business Portal** is Skaly Group's private, internal operations platform — a dark, data-dense workspace where a content/media agency runs its day: staff attendance, work allocation (tasks), shoot planning, the content pipeline (RAW → Finals → Posted), a cross-client content calendar, team chat, an AI management bot, and admin dashboards. There is a **web app** (Next.js / shadcn / Tailwind / TanStack tables) and a **native mobile app** (React Native + Expo).

This project is the design system that lets agents and developers build new Skaly screens, components, slides and assets on-brand.

## Sources

- `uploads/03-UIUX.md` — **authoritative** UI/UX specification v2.1 (colour system, typography, component library, every module layout, mobile spec, animation spec). This design system is derived from it.
- `uploads/prompt-1…5-*.md` — generic shadcn/marketing component integration prompts (Spline scene, glass settings card, hero sections, section-with-mockup, animated hero). These are *candidate library components*, not the product UI; they are **not** part of the portal's visual language and were intentionally not used as foundations.
- `uploads/Big_Shoulders.zip`, `DM_Sans.zip`, `DM_Mono.zip` — referenced in the brief but **not present** in the upload. The three families are open-source Google Fonts (the exact fonts, not substitutes); they are sourced via the Google Fonts CDN in `tokens/fonts.css`. Swap for self-hosted `@font-face` if you need offline.
- The colourful **lion logo** seen on the live login is **not supplied as a file**. `assets/skaly-mark.svg` is a gold monogram placeholder. Replace it with the real mark when available.

---

## CONTENT FUNDAMENTALS

How Skaly writes copy across the portal:

- **Voice:** plain, operational, calm. It tells you the state of the work, not a marketing story. "June 2025 is locked — read only." "Failed to save. Try again."
- **Person:** addresses the user directly and warmly at entry points ("Welcome back", "Good morning, Naaz"), then switches to neutral system voice inside the tools. Possessive "My" for personal scopes ("My tasks today", "My next shoot").
- **Casing:** Sentence case for everything — headings, buttons, labels, menu items. Module names are Title Case proper nouns (Content Calendar, Shoot Planner, Content Dropper, Work Allocation). Never ALL-CAPS in body; uppercase is reserved for tiny mono eyebrow labels (letter-spaced).
- **Status language:** a fixed, closed vocabulary — *No Activity, Under Progress, Ready, Posted, Pending, Rescheduled, To Do, In Progress, Blocked, Done, Cancelled, Scheduled, Confirmed, Completed*. Use these exact words; never invent synonyms.
- **Numbers & data:** always in DM Mono — counts ("11/13", "12/31"), periods ("Jun 2025"), timestamps ("14:32 · 06 Jun"), IDs ("TASK-4821"), file names and sizes. Dates are short and unambiguous.
- **Tone of system messages:** direct and recoverable. State what happened + the next action. Errors are never blamey: "Some changes couldn't be saved — the period was locked while you were offline."
- **Buttons:** verb-first and short — "Sign in", "Create task", "Add holiday", "Generate report", "Manual rollover". One gold primary action per surface.
- **Empty states:** a confident Big Shoulders headline + a quiet helper line + (optionally) one CTA. "Nothing here yet" / "No tasks today".
- **Emoji:** essentially none in product chrome. The spec uses a 💬 comment affordance on grid rows; otherwise meaning is carried by Lucide icons, status colour + text, never decorative emoji.

---

## VISUAL FOUNDATIONS

**The one rule: 60 / 30 / 10.** ~60% black surfaces, ~30% white/grey text, ~10% gold. Dark by default — *every* surface is dark. **Gold (`#FDC257`) is the only interaction colour and never appears without meaning** — it marks the single primary action, the active nav item, the current period, an unread count, the today row, an active grid column. Gold is used on dark only, never on white.

- **Colour:** a tight black family (`#0D0D0F` base → `#2A2A30` selected), a 4-step grey text ramp (`#F4F4F5` → `#3F3F46`), gold + its tints (hover `#FFD07A`, 15% chip, 12% column-dim, 6% today-row), and six status hues (green/blue/amber/red/teal/grey). Status colours render as chips at **15% background, 100% text**; colour is *never* the only signal — always paired with the status word.
- **Typography:** three required fonts, strict roles. **Big Shoulders Display** (condensed, heavy) for headings, module titles and big stat numbers — it's the brand's loudest voice. **DM Sans** for all UI text. **DM Mono** for all data. Type scale: page title 32 / stat 48 / section 24 / body 14 / caption 12 / data 13.
- **Spacing & density:** 4px base unit. "Whitespace is earned" — grids are dense (48px rows, 24px chips) and hold many clients × many days. Fixed structural sizes: 220px sidebar (56px icon-only), 56px topbar, sticky 80–200px first columns.
- **Backgrounds:** flat dark fills, layered by elevation (base → surface → elevated). No photographic or illustrative backgrounds in-app. The only decorative treatment is restrained: a faint gold radial glow and a low-opacity dot-grid on marketing-ish surfaces like the login brand panel. No busy gradients.
- **Corner radii:** generous — 16px base (`--radius`) on cards and modals, 12px on buttons/inputs/chips, full pills for badges and avatars.
- **Cards:** `--bg-elevated` fill, 1px `--border-subtle`, 16px radius, **no shadow by default** (flat on the dark canvas); shadow only when a surface truly floats (dropdowns, popovers, modals).
- **Borders:** the primary separator on dark — three weights (subtle/default/strong). Grids are defined by 1px borders, not shadow.
- **Shadows:** minimal and dark (`rgba(0,0,0,.4–.55)`); reserved for floating layers. The signature "elevation" cue for the **active nav item is an inset gold bar** (`inset 3px 0 0`), not a drop shadow and not a left border.
- **Transparency & blur:** modal backdrop is `rgba(0,0,0,.65)` + 4px blur. Mobile/glass mockups use ~15px backdrop-blur. Used sparingly, for layering depth only.
- **Hover / press / focus:** hover lifts the surface one step (`--bg-hover`) or lightens gold to `--accent-gold-hover`; press scales to ~0.97; focus is a **2px gold outline** on every focusable element (a11y). Status chips crossfade on change.
- **Motion:** fast and optimistic — interactions feel instant. Framer Motion timings: column highlight 80ms, chip crossfade 120ms, modal open 180ms (scale .96→1), page/row 200ms (y 8→0), toast 240ms. Easing `cubic-bezier(0.16, 1, 0.3, 1)`. No bouncy or infinite decorative loops in product chrome.
- **Imagery vibe:** the app itself is chrome-only (no stock imagery). Where avatars are needed, they're circular with deterministic colour-on-dark initials.

---

## ICONOGRAPHY

- **System:** **Lucide** (Lucide React in the app; `lucide-react-native` on mobile). 20px default in nav/toolbars, 16px inline, 22px on the mobile tab bar. 2px stroke, rounded caps — matches the calm, geometric feel. This design system loads Lucide from CDN (`unpkg.com/lucide`) in cards and UI kits and renders via `createIcons()` / a small `<Icon>` wrapper.
- **No hand-rolled SVG icons, no emoji-as-icons, no icon font.** Meaning is carried by Lucide + status colour + text.
- **Brand mark:** the Skaly lion. The real asset wasn't supplied — `assets/skaly-mark.svg` is a **gold monogram placeholder**; the notification bell in the spec uses the lion mark (outlined default, filled when unread). Replace the placeholder when the real SVG is available.
- **Status dots:** 6px gold dot at a chip's top-right marks a pipeline-triggered (auto-updated) value; a leading dot can echo the status colour.

---

## INDEX

**Root**
- `styles.css` — the single entry point consumers link (`@import`s only).
- `readme.md` — this guide. · `SKILL.md` — Agent-Skills-compatible front-matter.
- `_ds_bundle.js`, `_ds_manifest.json`, `_adherence.oxlintrc.json` — generated; do not edit.

**Tokens** (`tokens/`, all `@import`ed by `styles.css`)
- `fonts.css` (webfonts) · `colors.css` (60/30/10 + status + shadcn channels + aliases) · `typography.css` (families, scale, weights) · `spacing.css` (4px scale + structural dims) · `effects.css` (radius, borders, shadows, blur, motion).

**Components** (`components/`) — React primitives, exposed on `window.SkalyPortalDesignSystem_a5ef85`
- `core/` — Button, IconButton, Input, Select, Switch, Checkbox, Card, Avatar + AvatarStack, Tabs
- `feedback/` — StatusChip, Badge + Tag, Tooltip, Dialog, Toast, EmptyState
- `navigation/` — SidebarNav, PeriodSelector

**Guidelines** (`guidelines/`) — foundation specimen cards for the Design System tab (Colors, Type, Spacing, Brand).

**UI kits** (`ui_kits/`)
- `portal/` — web app: `login.html` (✅ built), plus screen sources `Shell.jsx`, `HomeScreen.jsx`, `CalendarScreen.jsx`, `LoginScreen.jsx` (interactive `index.html` and remaining screens in progress).
- `mobile/` — React Native app recreation (in progress).

**Assets** (`assets/`) — `skaly-mark.svg` (placeholder monogram).

> **Status:** tokens, all components + cards, foundation cards, and the redesigned login are complete. Remaining: finish the portal interactive shell + Tasks/Chat/Planner screens, the mobile kit, and sample slides.
