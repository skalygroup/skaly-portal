/* @ds-bundle: {"format":3,"namespace":"SkalyPortalDesignSystem_a5ef85","components":[{"name":"Avatar","sourcePath":"components/core/Avatar.jsx"},{"name":"AvatarStack","sourcePath":"components/core/Avatar.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Card","sourcePath":"components/core/Card.jsx"},{"name":"Checkbox","sourcePath":"components/core/Checkbox.jsx"},{"name":"IconButton","sourcePath":"components/core/IconButton.jsx"},{"name":"Input","sourcePath":"components/core/Input.jsx"},{"name":"Select","sourcePath":"components/core/Select.jsx"},{"name":"Switch","sourcePath":"components/core/Switch.jsx"},{"name":"Tabs","sourcePath":"components/core/Tabs.jsx"},{"name":"Badge","sourcePath":"components/feedback/Badge.jsx"},{"name":"Tag","sourcePath":"components/feedback/Badge.jsx"},{"name":"Dialog","sourcePath":"components/feedback/Dialog.jsx"},{"name":"EmptyState","sourcePath":"components/feedback/EmptyState.jsx"},{"name":"StatusChip","sourcePath":"components/feedback/StatusChip.jsx"},{"name":"Toast","sourcePath":"components/feedback/Toast.jsx"},{"name":"Tooltip","sourcePath":"components/feedback/Tooltip.jsx"},{"name":"PeriodSelector","sourcePath":"components/navigation/PeriodSelector.jsx"},{"name":"SidebarNav","sourcePath":"components/navigation/SidebarNav.jsx"}],"sourceHashes":{"components/core/Avatar.jsx":"c54fb3713f5a","components/core/Button.jsx":"268f0c96f27d","components/core/Card.jsx":"5a51cf0d1468","components/core/Checkbox.jsx":"b7d4aaaa2da0","components/core/IconButton.jsx":"ffc0db46dd0b","components/core/Input.jsx":"f85f314dc2c6","components/core/Select.jsx":"478a7c49d9d0","components/core/Switch.jsx":"07f8e94eed4b","components/core/Tabs.jsx":"6dd5aa810105","components/feedback/Badge.jsx":"e778c7acd4f4","components/feedback/Dialog.jsx":"11bcd219ab3d","components/feedback/EmptyState.jsx":"e8461a1236c0","components/feedback/StatusChip.jsx":"1fc84e42e909","components/feedback/Toast.jsx":"8e05a083e631","components/feedback/Tooltip.jsx":"7a7971376737","components/navigation/PeriodSelector.jsx":"dc810ad25120","components/navigation/SidebarNav.jsx":"b1ef0b907b09","ui_kits/portal/CalendarScreen.jsx":"4f45fbc332f2","ui_kits/portal/HomeScreen.jsx":"7664cfaf98a9","ui_kits/portal/LoginScreen.jsx":"c27ea7a27ec6","ui_kits/portal/Shell.jsx":"ac67b16e45f3"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.SkalyPortalDesignSystem_a5ef85 = window.SkalyPortalDesignSystem_a5ef85 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/core/Avatar.jsx
try { (() => {
const PALETTE = [['#FDC257', '#0D0D0F'], ['#3B82F6', '#F4F4F5'], ['#22C55E', '#0D0D0F'], ['#14B8A6', '#0D0D0F'], ['#F59E0B', '#0D0D0F'], ['#EF4444', '#F4F4F5']];
function initials(name = '') {
  return name.trim().split(/\s+/).slice(0, 2).map(w => w[0] || '').join('').toUpperCase();
}

/** Avatar — image or initials fallback on a deterministic colour. */
function Avatar({
  name = '',
  src,
  size = 32,
  style = {}
}) {
  const [broken, setBroken] = React.useState(false);
  const idx = name ? name.charCodeAt(0) % PALETTE.length : 0;
  const [bg, fg] = PALETTE[idx];
  const base = {
    width: size,
    height: size,
    flexShrink: 0,
    borderRadius: '50%',
    display: 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
    fontFamily: 'var(--font-body)',
    fontWeight: 600,
    fontSize: Math.max(10, Math.round(size * 0.4)),
    background: bg,
    color: fg,
    border: '1px solid rgba(255,255,255,0.08)',
    ...style
  };
  if (src && !broken) {
    return /*#__PURE__*/React.createElement("img", {
      src: src,
      alt: name,
      onError: () => setBroken(true),
      style: {
        ...base,
        objectFit: 'cover'
      }
    });
  }
  return /*#__PURE__*/React.createElement("span", {
    style: base,
    "aria-label": name
  }, initials(name));
}

/** Overlapping stack of avatars with optional +N overflow. */
function AvatarStack({
  people = [],
  size = 28,
  max = 4
}) {
  const shown = people.slice(0, max);
  const extra = people.length - shown.length;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center'
    }
  }, shown.map((p, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      marginLeft: i === 0 ? 0 : -size * 0.32,
      border: '2px solid var(--bg-elevated)',
      borderRadius: '50%'
    }
  }, /*#__PURE__*/React.createElement(Avatar, {
    name: typeof p === 'string' ? p : p.name,
    src: typeof p === 'string' ? undefined : p.src,
    size: size
  }))), extra > 0 && /*#__PURE__*/React.createElement("div", {
    style: {
      marginLeft: -size * 0.32,
      width: size,
      height: size,
      borderRadius: '50%',
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      background: 'var(--bg-hover)',
      color: 'var(--text-secondary)',
      border: '2px solid var(--bg-elevated)',
      fontFamily: 'var(--font-mono)',
      fontSize: Math.max(9, Math.round(size * 0.34))
    }
  }, "+", extra));
}
Object.assign(__ds_scope, { Avatar, AvatarStack });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Avatar.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Skaly Button — gold = action. 60/30/10: gold primary is the only
 * filled colour in the UI; everything else is dark/outline/ghost.
 */
function Button({
  children,
  variant = 'primary',
  size = 'md',
  disabled = false,
  iconLeft = null,
  iconRight = null,
  fullWidth = false,
  type = 'button',
  onClick,
  style = {},
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const [active, setActive] = React.useState(false);
  const sizes = {
    sm: {
      height: 32,
      padding: '0 12px',
      font: 13
    },
    md: {
      height: 40,
      padding: '0 16px',
      font: 14
    },
    lg: {
      height: 44,
      padding: '0 24px',
      font: 15
    }
  };
  const s = sizes[size] || sizes.md;
  const base = {
    display: 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    height: s.height,
    padding: s.padding,
    width: fullWidth ? '100%' : 'auto',
    fontFamily: 'var(--font-body)',
    fontSize: s.font,
    fontWeight: 600,
    lineHeight: 1,
    borderRadius: 'var(--radius-md)',
    border: '1px solid transparent',
    cursor: disabled ? 'not-allowed' : 'pointer',
    opacity: disabled ? 0.45 : 1,
    transition: 'background 120ms ease, color 120ms ease, border-color 120ms ease, transform 80ms ease',
    transform: active && !disabled ? 'scale(0.97)' : 'scale(1)',
    whiteSpace: 'nowrap',
    userSelect: 'none'
  };
  const variants = {
    primary: {
      background: hover ? 'var(--accent-gold-hover)' : 'var(--accent-gold)',
      color: 'var(--bg-base)'
    },
    secondary: {
      background: hover ? 'var(--bg-hover)' : 'var(--bg-elevated)',
      color: 'var(--text-primary)',
      borderColor: 'var(--border-default)'
    },
    ghost: {
      background: hover ? 'var(--bg-hover)' : 'transparent',
      color: 'var(--text-secondary)'
    },
    destructive: {
      background: hover ? 'rgba(239,68,68,0.18)' : 'rgba(239,68,68,0.12)',
      color: 'var(--status-red)',
      borderColor: 'rgba(239,68,68,0.4)'
    }
  };
  return /*#__PURE__*/React.createElement("button", _extends({
    type: type,
    disabled: disabled,
    onClick: onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => {
      setHover(false);
      setActive(false);
    },
    onMouseDown: () => setActive(true),
    onMouseUp: () => setActive(false),
    style: {
      ...base,
      ...(variants[variant] || variants.primary),
      ...style
    }
  }, rest), iconLeft, children, iconRight);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Card — elevated dark surface. Optional header (title + action) and padding control. */
function Card({
  children,
  title,
  action,
  padding = 16,
  elevated = false,
  style = {},
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      background: 'var(--bg-elevated)',
      border: '1px solid var(--border-subtle)',
      borderRadius: 'var(--radius)',
      boxShadow: elevated ? 'var(--shadow-md)' : 'none',
      overflow: 'hidden',
      ...style
    }
  }, rest), (title || action) && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      padding: `14px ${padding}px`,
      borderBottom: '1px solid var(--border-subtle)'
    }
  }, title && /*#__PURE__*/React.createElement("h3", {
    style: {
      margin: 0,
      fontFamily: 'var(--font-display)',
      fontWeight: 600,
      fontSize: 20,
      color: 'var(--text-primary)',
      letterSpacing: '0.01em'
    }
  }, title), action), /*#__PURE__*/React.createElement("div", {
    style: {
      padding
    }
  }, children));
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Card.jsx", error: String((e && e.message) || e) }); }

// components/core/Checkbox.jsx
try { (() => {
/** Checkbox — gold fill + dark check when checked. */
function Checkbox({
  checked,
  defaultChecked = false,
  disabled = false,
  onChange,
  label,
  style = {}
}) {
  const isControlled = checked !== undefined;
  const [internal, setInternal] = React.useState(defaultChecked);
  const on = isControlled ? checked : internal;
  const toggle = () => {
    if (disabled) return;
    if (!isControlled) setInternal(!on);
    onChange && onChange(!on);
  };
  const box = /*#__PURE__*/React.createElement("span", {
    role: "checkbox",
    "aria-checked": on,
    "aria-label": label,
    tabIndex: disabled ? -1 : 0,
    onClick: toggle,
    onKeyDown: e => {
      if (e.key === ' ' || e.key === 'Enter') {
        e.preventDefault();
        toggle();
      }
    },
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      width: 18,
      height: 18,
      flexShrink: 0,
      borderRadius: 'var(--radius-xs)',
      border: `1px solid ${on ? 'var(--accent-gold)' : 'var(--border-strong)'}`,
      background: on ? 'var(--accent-gold)' : 'transparent',
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? 0.5 : 1,
      transition: 'background 120ms ease, border-color 120ms ease',
      ...style
    }
  }, on && /*#__PURE__*/React.createElement("svg", {
    width: "11",
    height: "11",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "var(--bg-base)",
    strokeWidth: "4",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }, /*#__PURE__*/React.createElement("polyline", {
    points: "20 6 9 17 4 12"
  })));
  if (!label) return box;
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 8,
      cursor: disabled ? 'not-allowed' : 'pointer'
    }
  }, box, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: 14,
      color: 'var(--text-primary)'
    }
  }, label));
}
Object.assign(__ds_scope, { Checkbox });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Checkbox.jsx", error: String((e && e.message) || e) }); }

// components/core/IconButton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * IconButton — square icon-only control for toolbars, topbars,
 * row actions. Pass a Lucide icon node as children.
 */
function IconButton({
  children,
  size = 'md',
  variant = 'ghost',
  active = false,
  disabled = false,
  label,
  onClick,
  style = {},
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const dim = {
    sm: 32,
    md: 36,
    lg: 44
  }[size] || 36;
  const variants = {
    ghost: {
      background: active ? 'var(--bg-selected)' : hover ? 'var(--bg-hover)' : 'transparent',
      color: active ? 'var(--accent-gold)' : 'var(--text-secondary)',
      border: '1px solid transparent'
    },
    outline: {
      background: hover ? 'var(--bg-hover)' : 'var(--bg-elevated)',
      color: 'var(--text-primary)',
      border: '1px solid var(--border-default)'
    }
  };
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    "aria-label": label,
    title: label,
    disabled: disabled,
    onClick: onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      width: dim,
      height: dim,
      borderRadius: 'var(--radius-md)',
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? 0.4 : 1,
      transition: 'background 120ms ease, color 120ms ease',
      ...(variants[variant] || variants.ghost),
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { IconButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/IconButton.jsx", error: String((e && e.message) || e) }); }

// components/core/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Input — dark text field. Optional leading icon and label.
 * Focus ring is gold per a11y spec.
 */
function Input({
  label,
  value,
  defaultValue,
  placeholder,
  type = 'text',
  iconLeft = null,
  mono = false,
  disabled = false,
  error = false,
  hint,
  onChange,
  style = {},
  id,
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  const reactId = React.useId();
  const inputId = id || reactId;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 6,
      width: '100%'
    }
  }, label && /*#__PURE__*/React.createElement("label", {
    htmlFor: inputId,
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: 13,
      fontWeight: 600,
      color: 'var(--text-primary)'
    }
  }, label), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      height: 40,
      padding: '0 12px',
      background: 'var(--bg-elevated)',
      border: `1px solid ${error ? 'var(--status-red)' : focus ? 'var(--accent-gold)' : 'var(--border-default)'}`,
      borderRadius: 'var(--radius-md)',
      boxShadow: focus ? '0 0 0 2px var(--accent-gold-dim)' : 'none',
      opacity: disabled ? 0.5 : 1,
      transition: 'border-color 120ms ease, box-shadow 120ms ease'
    }
  }, iconLeft && /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--text-muted)',
      display: 'inline-flex'
    }
  }, iconLeft), /*#__PURE__*/React.createElement("input", _extends({
    id: inputId,
    type: type,
    value: value,
    defaultValue: defaultValue,
    placeholder: placeholder,
    disabled: disabled,
    onChange: onChange,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      flex: 1,
      minWidth: 0,
      height: '100%',
      background: 'transparent',
      border: 'none',
      outline: 'none',
      color: 'var(--text-primary)',
      fontFamily: mono ? 'var(--font-mono)' : 'var(--font-body)',
      fontSize: mono ? 13 : 14,
      ...style
    }
  }, rest))), hint && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: 12,
      color: error ? 'var(--status-red)' : 'var(--text-muted)'
    }
  }, hint));
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Input.jsx", error: String((e && e.message) || e) }); }

// components/core/Select.jsx
try { (() => {
/** Select — native dark dropdown styled to match inputs. */
function Select({
  label,
  value,
  defaultValue,
  options = [],
  placeholder,
  disabled = false,
  onChange,
  mono = false,
  id,
  style = {}
}) {
  const [focus, setFocus] = React.useState(false);
  const reactId = React.useId();
  const selId = id || reactId;
  const opts = options.map(o => typeof o === 'string' ? {
    value: o,
    label: o
  } : o);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 6,
      width: '100%'
    }
  }, label && /*#__PURE__*/React.createElement("label", {
    htmlFor: selId,
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: 13,
      fontWeight: 600,
      color: 'var(--text-primary)'
    }
  }, label), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      display: 'flex',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("select", {
    id: selId,
    value: value,
    defaultValue: defaultValue,
    disabled: disabled,
    onChange: onChange,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      appearance: 'none',
      WebkitAppearance: 'none',
      width: '100%',
      height: 40,
      padding: '0 36px 0 12px',
      background: 'var(--bg-elevated)',
      border: `1px solid ${focus ? 'var(--accent-gold)' : 'var(--border-default)'}`,
      borderRadius: 'var(--radius-md)',
      color: 'var(--text-primary)',
      fontFamily: mono ? 'var(--font-mono)' : 'var(--font-body)',
      fontSize: mono ? 13 : 14,
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? 0.5 : 1,
      outline: 'none',
      boxShadow: focus ? '0 0 0 2px var(--accent-gold-dim)' : 'none',
      transition: 'border-color 120ms ease, box-shadow 120ms ease',
      ...style
    }
  }, placeholder && /*#__PURE__*/React.createElement("option", {
    value: "",
    disabled: true
  }, placeholder), opts.map(o => /*#__PURE__*/React.createElement("option", {
    key: o.value,
    value: o.value
  }, o.label))), /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      right: 12,
      pointerEvents: 'none',
      color: 'var(--text-muted)',
      display: 'inline-flex'
    }
  }, /*#__PURE__*/React.createElement("svg", {
    width: "16",
    height: "16",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }, /*#__PURE__*/React.createElement("polyline", {
    points: "6 9 12 15 18 9"
  })))));
}
Object.assign(__ds_scope, { Select });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Select.jsx", error: String((e && e.message) || e) }); }

// components/core/Switch.jsx
try { (() => {
/** Switch — gold when on. Used for toggles, attendance, preferences. */
function Switch({
  checked,
  defaultChecked = false,
  disabled = false,
  onChange,
  label,
  style = {}
}) {
  const isControlled = checked !== undefined;
  const [internal, setInternal] = React.useState(defaultChecked);
  const on = isControlled ? checked : internal;
  const toggle = () => {
    if (disabled) return;
    if (!isControlled) setInternal(!on);
    onChange && onChange(!on);
  };
  const knob = /*#__PURE__*/React.createElement("button", {
    type: "button",
    role: "switch",
    "aria-checked": on,
    "aria-label": label,
    disabled: disabled,
    onClick: toggle,
    style: {
      position: 'relative',
      width: 40,
      height: 24,
      flexShrink: 0,
      borderRadius: 'var(--radius-full)',
      border: 'none',
      background: on ? 'var(--accent-gold)' : 'var(--bg-hover)',
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? 0.5 : 1,
      transition: 'background 150ms ease',
      padding: 0,
      ...style
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      top: 2,
      left: on ? 18 : 2,
      width: 20,
      height: 20,
      borderRadius: '50%',
      background: on ? 'var(--bg-base)' : 'var(--text-secondary)',
      transition: 'left 150ms cubic-bezier(0.16,1,0.3,1), background 150ms ease'
    }
  }));
  if (!label) return knob;
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 10,
      cursor: disabled ? 'not-allowed' : 'pointer'
    }
  }, knob, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: 14,
      color: 'var(--text-primary)'
    }
  }, label));
}
Object.assign(__ds_scope, { Switch });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Switch.jsx", error: String((e && e.message) || e) }); }

// components/core/Tabs.jsx
try { (() => {
/** Tabs — underline-style. Active tab text + indicator are gold. */
function Tabs({
  tabs = [],
  value,
  defaultValue,
  onChange,
  style = {}
}) {
  const items = tabs.map(t => typeof t === 'string' ? {
    value: t,
    label: t
  } : t);
  const isControlled = value !== undefined;
  const [internal, setInternal] = React.useState(defaultValue ?? (items[0] && items[0].value));
  const active = isControlled ? value : internal;
  const select = v => {
    if (!isControlled) setInternal(v);
    onChange && onChange(v);
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 4,
      borderBottom: '1px solid var(--border-subtle)',
      ...style
    }
  }, items.map(t => {
    const on = t.value === active;
    return /*#__PURE__*/React.createElement("button", {
      key: t.value,
      type: "button",
      onClick: () => select(t.value),
      style: {
        position: 'relative',
        padding: '10px 14px',
        background: 'transparent',
        border: 'none',
        cursor: 'pointer',
        fontFamily: 'var(--font-body)',
        fontSize: 14,
        fontWeight: on ? 600 : 500,
        color: on ? 'var(--accent-gold)' : 'var(--text-secondary)',
        transition: 'color 120ms ease',
        display: 'inline-flex',
        alignItems: 'center',
        gap: 8
      }
    }, t.label, t.count != null && /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--font-mono)',
        fontSize: 11,
        padding: '1px 6px',
        borderRadius: 'var(--radius-full)',
        background: on ? 'var(--accent-gold-15)' : 'var(--bg-hover)',
        color: on ? 'var(--accent-gold)' : 'var(--text-muted)'
      }
    }, t.count), /*#__PURE__*/React.createElement("span", {
      style: {
        position: 'absolute',
        left: 0,
        right: 0,
        bottom: -1,
        height: 2,
        background: on ? 'var(--accent-gold)' : 'transparent',
        transition: 'background 120ms ease'
      }
    }));
  }));
}
Object.assign(__ds_scope, { Tabs });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Tabs.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Badge.jsx
try { (() => {
/** Badge — small count / label pill. Gold variant for unread counts. */
function Badge({
  children,
  variant = 'neutral',
  mono = true,
  style = {}
}) {
  const variants = {
    neutral: {
      background: 'var(--bg-hover)',
      color: 'var(--text-secondary)'
    },
    gold: {
      background: 'var(--accent-gold)',
      color: 'var(--bg-base)'
    },
    outline: {
      background: 'transparent',
      color: 'var(--text-secondary)',
      border: '1px solid var(--border-default)'
    },
    red: {
      background: 'var(--status-red)',
      color: 'var(--text-primary)'
    }
  };
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      minWidth: 18,
      height: 18,
      padding: '0 6px',
      borderRadius: 'var(--radius-full)',
      fontFamily: mono ? 'var(--font-mono)' : 'var(--font-body)',
      fontSize: 11,
      fontWeight: 600,
      lineHeight: 1,
      ...(variants[variant] || variants.neutral),
      ...style
    }
  }, children);
}

/** Role / category tag — outlined pill in DM Sans. */
function Tag({
  children,
  color,
  style = {}
}) {
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      height: 22,
      padding: '0 10px',
      borderRadius: 'var(--radius-full)',
      border: `1px solid ${color ? color : 'var(--border-default)'}`,
      background: color ? `${color}1f` : 'var(--bg-elevated)',
      color: color || 'var(--text-secondary)',
      fontFamily: 'var(--font-body)',
      fontSize: 12,
      fontWeight: 500,
      whiteSpace: 'nowrap',
      ...style
    }
  }, children);
}
Object.assign(__ds_scope, { Badge, Tag });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Badge.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Dialog.jsx
try { (() => {
/**
 * Dialog — modal over a blurred backdrop. Framer-spec timing approximated
 * with CSS (scale 0.96 → 1, 180ms). Close on Escape, backdrop, or button.
 */
function Dialog({
  open = true,
  title,
  children,
  footer,
  onClose,
  width = 440
}) {
  React.useEffect(() => {
    if (!open) return;
    const onKey = e => {
      if (e.key === 'Escape') onClose && onClose();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [open, onClose]);
  if (!open) return null;
  return /*#__PURE__*/React.createElement("div", {
    onMouseDown: e => {
      if (e.target === e.currentTarget) onClose && onClose();
    },
    style: {
      position: 'fixed',
      inset: 0,
      zIndex: 1000,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      background: 'var(--backdrop)',
      backdropFilter: 'blur(4px)',
      WebkitBackdropFilter: 'blur(4px)',
      padding: 24,
      animation: 'sk-fade 150ms ease'
    }
  }, /*#__PURE__*/React.createElement("div", {
    role: "dialog",
    "aria-modal": "true",
    "aria-label": title,
    style: {
      width: '100%',
      maxWidth: width,
      background: 'var(--bg-elevated)',
      border: '1px solid var(--border-default)',
      borderRadius: 'var(--radius)',
      boxShadow: 'var(--shadow-lg)',
      overflow: 'hidden',
      animation: 'sk-pop 180ms cubic-bezier(0.16,1,0.3,1)'
    }
  }, title && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      padding: '16px 20px',
      borderBottom: '1px solid var(--border-subtle)'
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      margin: 0,
      fontFamily: 'var(--font-display)',
      fontWeight: 600,
      fontSize: 22,
      color: 'var(--text-primary)'
    }
  }, title), /*#__PURE__*/React.createElement("button", {
    onClick: onClose,
    "aria-label": "Close",
    style: {
      background: 'transparent',
      border: 'none',
      cursor: 'pointer',
      color: 'var(--text-muted)',
      display: 'inline-flex',
      padding: 4
    }
  }, /*#__PURE__*/React.createElement("svg", {
    width: "18",
    height: "18",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2",
    strokeLinecap: "round"
  }, /*#__PURE__*/React.createElement("line", {
    x1: "18",
    y1: "6",
    x2: "6",
    y2: "18"
  }), /*#__PURE__*/React.createElement("line", {
    x1: "6",
    y1: "6",
    x2: "18",
    y2: "18"
  })))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 20,
      fontFamily: 'var(--font-body)',
      fontSize: 14,
      color: 'var(--text-secondary)',
      lineHeight: 1.5
    }
  }, children), footer && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'flex-end',
      gap: 10,
      padding: '14px 20px',
      borderTop: '1px solid var(--border-subtle)'
    }
  }, footer)), /*#__PURE__*/React.createElement("style", null, `@keyframes sk-pop{from{opacity:0;transform:scale(0.96)}to{opacity:1;transform:scale(1)}}@keyframes sk-fade{from{opacity:0}to{opacity:1}}`));
}
Object.assign(__ds_scope, { Dialog });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Dialog.jsx", error: String((e && e.message) || e) }); }

// components/feedback/EmptyState.jsx
try { (() => {
/** EmptyState — Big Shoulders headline + helper text + optional CTA. */
function EmptyState({
  icon,
  title = 'Nothing here yet',
  message,
  action,
  style = {}
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      textAlign: 'center',
      gap: 8,
      padding: '48px 24px',
      ...style
    }
  }, icon && /*#__PURE__*/React.createElement("div", {
    style: {
      color: 'var(--text-disabled)',
      marginBottom: 4
    }
  }, icon), /*#__PURE__*/React.createElement("h3", {
    style: {
      margin: 0,
      fontFamily: 'var(--font-display)',
      fontWeight: 600,
      fontSize: 24,
      color: 'var(--text-secondary)'
    }
  }, title), message && /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      maxWidth: 320,
      fontFamily: 'var(--font-body)',
      fontSize: 14,
      color: 'var(--text-muted)',
      lineHeight: 1.5
    }
  }, message), action && /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 12
    }
  }, action));
}
Object.assign(__ds_scope, { EmptyState });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/EmptyState.jsx", error: String((e && e.message) || e) }); }

// components/feedback/StatusChip.jsx
try { (() => {
/**
 * StatusChip — the portal's core status token. Background is the status
 * colour @ 15%, text @ 100%. Cancelled is struck through. Some statuses
 * render no chip (No Activity / Unset) — handle that at the call site.
 */
const STATUS = {
  // label: [colorVar, bgVar, strike?]
  'Under Progress': ['--status-blue', '--status-blue-bg'],
  'In Progress': ['--status-blue', '--status-blue-bg'],
  'Scheduled': ['--status-blue', '--status-blue-bg'],
  'Ready': ['--status-teal', '--status-teal-bg'],
  'Posted': ['--status-gold', '--accent-gold-15'],
  'Confirmed': ['--status-gold', '--accent-gold-15'],
  'Pending': ['--status-amber', '--status-amber-bg'],
  'Awaiting': ['--status-amber', '--status-amber-bg'],
  'Done': ['--status-green', '--status-green-bg'],
  'Completed': ['--status-green', '--status-green-bg'],
  'Blocked': ['--status-red', '--status-red-bg'],
  'Overdue': ['--status-red', '--status-red-bg'],
  'Failed': ['--status-red', '--status-red-bg'],
  'To Do': ['--status-grey', '--status-grey-bg'],
  'Rescheduled': ['--status-grey', '--status-grey-bg'],
  'Cancelled': ['--status-grey', '--status-grey-bg', true],
  'Locked': ['--status-grey', '--status-grey-bg']
};
function StatusChip({
  status,
  label,
  dot = false,
  trigger = false,
  style = {}
}) {
  const key = status || label;
  const entry = STATUS[key] || ['--status-grey', '--status-grey-bg'];
  const [color, bg, strike] = entry;
  return /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'relative',
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6,
      height: 24,
      padding: '0 10px',
      borderRadius: 'var(--radius-md)',
      background: `var(${bg})`,
      color: `var(${color})`,
      fontFamily: 'var(--font-body)',
      fontSize: 12,
      fontWeight: 500,
      textDecoration: strike ? 'line-through' : 'none',
      whiteSpace: 'nowrap',
      ...style
    }
  }, dot && /*#__PURE__*/React.createElement("span", {
    style: {
      width: 6,
      height: 6,
      borderRadius: '50%',
      background: `var(${color})`
    }
  }), key, trigger && /*#__PURE__*/React.createElement("span", {
    title: "Auto-updated from Content Dropper",
    style: {
      position: 'absolute',
      top: -3,
      right: -3,
      width: 6,
      height: 6,
      borderRadius: '50%',
      background: 'var(--accent-gold)'
    }
  }));
}
Object.assign(__ds_scope, { StatusChip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/StatusChip.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Toast.jsx
try { (() => {
/** Toast — bottom-right notification. Variants map to status colours. */
function Toast({
  title,
  message,
  variant = 'info',
  action,
  onClose,
  style = {}
}) {
  const accent = {
    info: 'var(--accent-gold)',
    success: 'var(--status-green)',
    error: 'var(--status-red)',
    warning: 'var(--status-amber)'
  }[variant] || 'var(--accent-gold)';
  return /*#__PURE__*/React.createElement("div", {
    role: "status",
    style: {
      display: 'flex',
      alignItems: 'flex-start',
      gap: 12,
      width: 340,
      padding: '14px 16px',
      background: 'var(--bg-elevated)',
      border: '1px solid var(--border-default)',
      borderLeft: `3px solid ${accent}`,
      borderRadius: 'var(--radius-md)',
      boxShadow: 'var(--shadow-lg)',
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, title && /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: 14,
      fontWeight: 600,
      color: 'var(--text-primary)'
    }
  }, title), message && /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: 13,
      color: 'var(--text-secondary)',
      marginTop: 2
    }
  }, message), action && /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 10
    }
  }, action)), onClose && /*#__PURE__*/React.createElement("button", {
    onClick: onClose,
    "aria-label": "Dismiss",
    style: {
      background: 'transparent',
      border: 'none',
      cursor: 'pointer',
      color: 'var(--text-muted)',
      padding: 2,
      display: 'inline-flex'
    }
  }, /*#__PURE__*/React.createElement("svg", {
    width: "16",
    height: "16",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2",
    strokeLinecap: "round"
  }, /*#__PURE__*/React.createElement("line", {
    x1: "18",
    y1: "6",
    x2: "6",
    y2: "18"
  }), /*#__PURE__*/React.createElement("line", {
    x1: "6",
    y1: "6",
    x2: "18",
    y2: "18"
  }))));
}
Object.assign(__ds_scope, { Toast });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Toast.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Tooltip.jsx
try { (() => {
/** Tooltip — dark elevated bubble on hover/focus. */
function Tooltip({
  children,
  content,
  side = 'top',
  style = {}
}) {
  const [open, setOpen] = React.useState(false);
  const pos = {
    top: {
      bottom: '100%',
      left: '50%',
      transform: 'translateX(-50%)',
      marginBottom: 8
    },
    bottom: {
      top: '100%',
      left: '50%',
      transform: 'translateX(-50%)',
      marginTop: 8
    },
    left: {
      right: '100%',
      top: '50%',
      transform: 'translateY(-50%)',
      marginRight: 8
    },
    right: {
      left: '100%',
      top: '50%',
      transform: 'translateY(-50%)',
      marginLeft: 8
    }
  };
  return /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'relative',
      display: 'inline-flex'
    },
    onMouseEnter: () => setOpen(true),
    onMouseLeave: () => setOpen(false),
    onFocus: () => setOpen(true),
    onBlur: () => setOpen(false)
  }, children, open && /*#__PURE__*/React.createElement("span", {
    role: "tooltip",
    style: {
      position: 'absolute',
      zIndex: 100,
      ...pos[side],
      padding: '6px 10px',
      background: 'var(--bg-elevated)',
      border: '1px solid var(--border-default)',
      borderRadius: 'var(--radius-sm)',
      boxShadow: 'var(--shadow-md)',
      color: 'var(--text-primary)',
      fontFamily: 'var(--font-body)',
      fontSize: 12,
      fontWeight: 500,
      whiteSpace: 'nowrap',
      pointerEvents: 'none',
      ...style
    }
  }, content));
}
Object.assign(__ds_scope, { Tooltip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Tooltip.jsx", error: String((e && e.message) || e) }); }

// components/navigation/PeriodSelector.jsx
try { (() => {
/**
 * PeriodSelector — sits below the logo. Current month in gold (DM Mono),
 * chevron to expand history. Past months in grey.
 */
function PeriodSelector({
  period = 'June 2025',
  isPast = false,
  onClick,
  expanded = false,
  style = {}
}) {
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      gap: 8,
      width: '100%',
      height: 40,
      padding: '0 12px',
      background: hover ? 'var(--bg-hover)' : 'var(--bg-elevated)',
      border: '1px solid var(--border-subtle)',
      borderRadius: 'var(--radius-sm)',
      cursor: 'pointer',
      ...style
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("svg", {
    width: "16",
    height: "16",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "var(--text-muted)",
    strokeWidth: "2",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }, /*#__PURE__*/React.createElement("rect", {
    x: "3",
    y: "4",
    width: "18",
    height: "18",
    rx: "2"
  }), /*#__PURE__*/React.createElement("line", {
    x1: "16",
    y1: "2",
    x2: "16",
    y2: "6"
  }), /*#__PURE__*/React.createElement("line", {
    x1: "8",
    y1: "2",
    x2: "8",
    y2: "6"
  }), /*#__PURE__*/React.createElement("line", {
    x1: "3",
    y1: "10",
    x2: "21",
    y2: "10"
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 13,
      fontWeight: 500,
      color: isPast ? 'var(--text-secondary)' : 'var(--accent-gold)'
    }
  }, period)), /*#__PURE__*/React.createElement("svg", {
    width: "16",
    height: "16",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "var(--text-muted)",
    strokeWidth: "2",
    strokeLinecap: "round",
    strokeLinejoin: "round",
    style: {
      transform: expanded ? 'rotate(180deg)' : 'none',
      transition: 'transform 150ms ease'
    }
  }, /*#__PURE__*/React.createElement("polyline", {
    points: "6 9 12 15 18 9"
  })));
}
Object.assign(__ds_scope, { PeriodSelector });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/PeriodSelector.jsx", error: String((e && e.message) || e) }); }

// components/navigation/SidebarNav.jsx
try { (() => {
/**
 * SidebarNav — the portal's left rail. Active item uses an inset gold bar
 * (NOT a left border) and gold text. Pass items with {id,label,icon,badge}.
 */
function SidebarNav({
  items = [],
  activeId,
  onSelect,
  header,
  footer,
  width = 220,
  style = {}
}) {
  return /*#__PURE__*/React.createElement("nav", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      width,
      height: '100%',
      background: 'var(--bg-surface)',
      borderRight: '1px solid var(--border-subtle)',
      ...style
    }
  }, header && /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '16px 16px 8px'
    }
  }, header), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 2,
      padding: 8,
      flex: 1,
      overflowY: 'auto'
    }
  }, items.map(it => /*#__PURE__*/React.createElement(NavItem, {
    key: it.id,
    item: it,
    active: it.id === activeId,
    onSelect: onSelect
  }))), footer && /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 12,
      borderTop: '1px solid var(--border-subtle)'
    }
  }, footer));
}
function NavItem({
  item,
  active,
  onSelect
}) {
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: () => onSelect && onSelect(item.id),
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      position: 'relative',
      display: 'flex',
      alignItems: 'center',
      gap: 12,
      height: 40,
      padding: '0 12px',
      width: '100%',
      background: active ? 'var(--bg-selected)' : hover ? 'var(--bg-hover)' : 'transparent',
      boxShadow: active ? 'inset 3px 0 0 var(--accent-gold)' : 'none',
      border: 'none',
      borderRadius: 'var(--radius-sm)',
      cursor: 'pointer',
      textAlign: 'left',
      color: active ? 'var(--accent-gold)' : 'var(--text-secondary)',
      fontFamily: 'var(--font-body)',
      fontSize: 14,
      fontWeight: active ? 600 : 500,
      transition: 'background 120ms ease, color 120ms ease'
    }
  }, item.icon && /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      flexShrink: 0
    }
  }, item.icon), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      whiteSpace: 'nowrap',
      overflow: 'hidden',
      textOverflow: 'ellipsis'
    }
  }, item.label), item.badge != null && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 11,
      fontWeight: 600,
      minWidth: 18,
      height: 18,
      padding: '0 5px',
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      borderRadius: 'var(--radius-full)',
      background: active ? 'var(--accent-gold-15)' : 'var(--bg-elevated)',
      color: active ? 'var(--accent-gold)' : 'var(--text-muted)'
    }
  }, item.badge));
}
Object.assign(__ds_scope, { SidebarNav });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/SidebarNav.jsx", error: String((e && e.message) || e) }); }

// ui_kits/portal/CalendarScreen.jsx
try { (() => {
/* Content Calendar — the signature grid. Sticky date column, client columns,
   today-row tint, gold column highlight on active cell, click-to-edit popover. */
const DS_C = window.SkalyPortalDesignSystem_a5ef85;
const CLIENTS = ['Aurora Cafe', 'Lumen Realty', 'Verde Fitness', 'Nimbus Tech', 'Coral Salon', 'Orbit Media'];
const STATUS_CYCLE = ['', 'To Do', 'Under Progress', 'Ready', 'Posted', 'Blocked'];
function seedGrid() {
  const days = [];
  const pool = ['', '', 'Posted', 'Ready', 'Under Progress', 'To Do', 'Pending', 'Blocked', 'Done'];
  for (let d = 1; d <= 14; d++) {
    const row = CLIENTS.map((c, ci) => pool[(d * 3 + ci * 5) % pool.length]);
    days.push({
      d,
      row
    });
  }
  return days;
}
function CalendarScreen() {
  const {
    Icon
  } = window.PortalShell;
  const [grid, setGrid] = React.useState(seedGrid);
  const [active, setActive] = React.useState(null); // {d, ci}
  const [editing, setEditing] = React.useState(null); // {d, ci, x, y}
  const TODAY = 6;
  const setCell = (d, ci, status) => {
    setGrid(g => g.map(r => r.d === d ? {
      ...r,
      row: r.row.map((s, i) => i === ci ? status : s)
    } : r));
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 24,
      height: '100%',
      boxSizing: 'border-box',
      display: 'flex',
      flexDirection: 'column',
      gap: 14
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement(DS_C.Tabs, {
    tabs: ['Calendar', 'Pipeline'],
    defaultValue: "Calendar"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 12,
      color: 'var(--text-muted)'
    }
  }, CLIENTS.length, " clients \xB7 June 2025"), /*#__PURE__*/React.createElement(DS_C.Button, {
    size: "sm",
    variant: "secondary",
    iconLeft: /*#__PURE__*/React.createElement(Icon, {
      name: "sliders-horizontal",
      size: 16
    })
  }, "Filter"))), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      overflow: 'auto',
      border: '1px solid var(--border-subtle)',
      borderRadius: 'var(--radius)',
      background: 'var(--bg-surface)',
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement("table", {
    style: {
      borderCollapse: 'collapse',
      width: '100%',
      minWidth: 720
    }
  }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, /*#__PURE__*/React.createElement("th", {
    style: {
      position: 'sticky',
      left: 0,
      top: 0,
      zIndex: 3,
      width: 80,
      background: 'var(--bg-elevated)',
      borderBottom: '1px solid var(--border-default)',
      borderRight: '1px solid var(--border-default)',
      padding: '10px 12px',
      textAlign: 'left'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 11,
      color: 'var(--text-muted)',
      textTransform: 'uppercase',
      letterSpacing: '.06em'
    }
  }, "Date")), CLIENTS.map((c, ci) => /*#__PURE__*/React.createElement("th", {
    key: c,
    style: {
      position: 'sticky',
      top: 0,
      zIndex: 2,
      minWidth: 110,
      background: 'var(--bg-elevated)',
      borderBottom: '1px solid var(--border-default)',
      borderRight: '1px solid var(--border-subtle)',
      padding: '10px 12px',
      textAlign: 'left'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: 13,
      fontWeight: 600,
      color: active && active.ci === ci ? 'var(--accent-gold)' : 'var(--text-primary)',
      whiteSpace: 'nowrap'
    }
  }, c))))), /*#__PURE__*/React.createElement("tbody", null, grid.map(({
    d,
    row
  }) => {
    const isToday = d === TODAY;
    return /*#__PURE__*/React.createElement("tr", {
      key: d,
      style: {
        background: isToday ? 'var(--accent-gold-06)' : 'transparent'
      }
    }, /*#__PURE__*/React.createElement("td", {
      style: {
        position: 'sticky',
        left: 0,
        zIndex: 1,
        background: isToday ? '#181510' : 'var(--bg-surface)',
        borderRight: '1px solid var(--border-default)',
        borderBottom: '1px solid var(--border-subtle)',
        padding: '0 12px',
        height: 48
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--font-mono)',
        fontSize: 13,
        color: isToday ? 'var(--accent-gold)' : 'var(--text-secondary)'
      }
    }, String(d).padStart(2, '0'), " Jun")), row.map((status, ci) => {
      const isActive = active && active.d === d && active.ci === ci;
      const colActive = active && active.ci === ci;
      return /*#__PURE__*/React.createElement("td", {
        key: ci,
        onClick: e => {
          const r = e.currentTarget.getBoundingClientRect();
          const host = e.currentTarget.closest('[data-cal-host]').getBoundingClientRect();
          setActive({
            d,
            ci
          });
          setEditing({
            d,
            ci,
            x: r.left - host.left,
            y: r.top - host.top + 50
          });
        },
        style: {
          height: 48,
          padding: '0 10px',
          cursor: 'pointer',
          borderRight: '1px solid var(--border-subtle)',
          borderBottom: '1px solid var(--border-subtle)',
          background: isActive ? 'var(--accent-gold-dim)' : colActive ? 'rgba(253,194,87,0.04)' : 'transparent',
          boxShadow: isActive ? 'inset 1px 0 0 var(--accent-gold-border), inset -1px 0 0 var(--accent-gold-border)' : 'none',
          transition: 'background 80ms ease'
        }
      }, status ? /*#__PURE__*/React.createElement(DS_C.StatusChip, {
        status: status,
        trigger: status === 'Posted' && ci % 2 === 0
      }) : /*#__PURE__*/React.createElement("span", {
        style: {
          color: 'var(--text-disabled)',
          fontFamily: 'var(--font-mono)',
          fontSize: 13
        }
      }, "\u2014"));
    }));
  }))), /*#__PURE__*/React.createElement("div", {
    "data-cal-host": true,
    style: {
      position: 'absolute',
      inset: 0,
      pointerEvents: 'none'
    }
  }), editing && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    onClick: () => {
      setEditing(null);
      setActive(null);
    },
    style: {
      position: 'fixed',
      inset: 0,
      zIndex: 40
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: Math.min(editing.x, 560),
      top: editing.y,
      zIndex: 50,
      width: 220,
      background: 'var(--bg-elevated)',
      border: '1px solid var(--border-default)',
      borderRadius: 'var(--radius-md)',
      boxShadow: 'var(--shadow-lg)',
      padding: 12,
      display: 'flex',
      flexDirection: 'column',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 11,
      color: 'var(--text-muted)'
    }
  }, CLIENTS[editing.ci], " \xB7 ", String(editing.d).padStart(2, '0'), " Jun"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      gap: 6
    }
  }, STATUS_CYCLE.filter(Boolean).map(s => /*#__PURE__*/React.createElement("span", {
    key: s,
    onClick: () => {
      setCell(editing.d, editing.ci, s);
      setEditing(null);
      setActive(null);
    },
    style: {
      cursor: 'pointer'
    }
  }, /*#__PURE__*/React.createElement(DS_C.StatusChip, {
    status: s
  })))), /*#__PURE__*/React.createElement("textarea", {
    placeholder: "Add note\u2026",
    style: {
      width: '100%',
      boxSizing: 'border-box',
      minHeight: 52,
      resize: 'none',
      background: 'var(--bg-base)',
      border: '1px solid var(--border-default)',
      borderRadius: 'var(--radius-sm)',
      color: 'var(--text-primary)',
      fontFamily: 'var(--font-body)',
      fontSize: 13,
      padding: 8,
      outline: 'none'
    }
  })))), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: 12,
      color: 'var(--text-muted)',
      display: 'flex',
      alignItems: 'center',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 6,
      height: 6,
      borderRadius: '50%',
      background: 'var(--accent-gold)'
    }
  }), " gold dot = auto-updated from Content Dropper \xB7 click a cell to edit"));
}
window.CalendarScreen = CalendarScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/portal/CalendarScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/portal/HomeScreen.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* Home (Manager view): stat row + today's content + upcoming shoots,
   with a right-hand activity feed. Quick actions open a Dialog. */
const DS_H = window.SkalyPortalDesignSystem_a5ef85;
const STATS = [{
  label: 'Team present',
  value: '11/13',
  tone: 'green'
}, {
  label: 'Tasks due today',
  value: '8',
  tone: 'gold'
}, {
  label: 'Shoots this week',
  value: '5',
  tone: 'gold'
}, {
  label: 'Posts pending',
  value: '3',
  tone: 'amber'
}];
const TODAY = [{
  client: 'Aurora Cafe',
  status: 'Posted'
}, {
  client: 'Lumen Realty',
  status: 'Ready'
}, {
  client: 'Verde Fitness',
  status: 'Under Progress'
}, {
  client: 'Nimbus Tech',
  status: 'Pending'
}, {
  client: 'Coral Salon',
  status: 'Blocked'
}];
const SHOOTS = [{
  client: 'Lumen Realty',
  when: 'Tue · 10:00',
  who: ['Sohail', 'Aman']
}, {
  client: 'Verde Fitness',
  when: 'Wed · 14:30',
  who: ['Priya']
}, {
  client: 'Aurora Cafe',
  when: 'Thu · 09:00',
  who: ['Sohail', 'Ravi', 'Aman']
}];
const FEED = [{
  who: 'Sohail',
  what: 'marked Aurora Cafe reel as Posted',
  t: '14:32'
}, {
  who: 'Priya',
  what: 'uploaded 12 finals for Verde Fitness',
  t: '13:58'
}, {
  who: 'Aman',
  what: 'rescheduled Nimbus shoot to Fri',
  t: '11:20'
}, {
  who: 'Naaz',
  what: 'approved 3 signup requests',
  t: '10:05'
}, {
  who: 'Ravi',
  what: 'commented on Coral Salon pipeline',
  t: '09:41'
}];
function StatCard({
  label,
  value,
  tone
}) {
  const color = tone === 'green' ? 'var(--status-green)' : tone === 'amber' ? 'var(--status-amber)' : 'var(--accent-gold)';
  return /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      background: 'var(--bg-elevated)',
      border: '1px solid var(--border-subtle)',
      borderRadius: 'var(--radius)',
      padding: 18
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 700,
      fontSize: 40,
      lineHeight: 1,
      color
    }
  }, value), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: 13,
      color: 'var(--text-muted)',
      marginTop: 6
    }
  }, label));
}
function HomeScreen() {
  const {
    Icon
  } = window.PortalShell;
  const [dlg, setDlg] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 24,
      display: 'grid',
      gridTemplateColumns: '1fr 320px',
      gap: 20,
      alignItems: 'start'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 20
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 700,
      fontSize: 28,
      color: 'var(--text-primary)'
    }
  }, "Good morning, Naaz"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 12,
      color: 'var(--text-muted)',
      marginTop: 2
    }
  }, "Friday \xB7 June 2025")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement(DS_H.Button, {
    size: "sm",
    iconLeft: /*#__PURE__*/React.createElement(Icon, {
      name: "plus",
      size: 16
    }),
    onClick: () => setDlg(true)
  }, "New task"), /*#__PURE__*/React.createElement(DS_H.Button, {
    size: "sm",
    variant: "secondary",
    iconLeft: /*#__PURE__*/React.createElement(Icon, {
      name: "file-text",
      size: 16
    })
  }, "Report"))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 14
    }
  }, STATS.map(s => /*#__PURE__*/React.createElement(StatCard, _extends({
    key: s.label
  }, s)))), /*#__PURE__*/React.createElement(DS_H.Card, {
    title: "Today's content"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column'
    }
  }, TODAY.map((r, i) => /*#__PURE__*/React.createElement("div", {
    key: r.client,
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      height: 44,
      borderTop: i ? '1px solid var(--border-subtle)' : 'none'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: 14,
      color: 'var(--text-primary)'
    }
  }, r.client), /*#__PURE__*/React.createElement(DS_H.StatusChip, {
    status: r.status
  }))))), /*#__PURE__*/React.createElement(DS_H.Card, {
    title: "Upcoming shoots this week"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column'
    }
  }, SHOOTS.map((r, i) => /*#__PURE__*/React.createElement("div", {
    key: r.client,
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      height: 48,
      borderTop: i ? '1px solid var(--border-subtle)' : 'none'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--text-muted)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "camera",
    size: 16
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: 14,
      color: 'var(--text-primary)'
    }
  }, r.client)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 14
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 12,
      color: 'var(--text-secondary)'
    }
  }, r.when), /*#__PURE__*/React.createElement(DS_H.AvatarStack, {
    people: r.who,
    size: 26
  }))))))), /*#__PURE__*/React.createElement(DS_H.Card, {
    title: "Activity"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 0
    }
  }, FEED.map((f, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      display: 'flex',
      gap: 10,
      padding: '10px 0',
      borderTop: i ? '1px solid var(--border-subtle)' : 'none'
    }
  }, /*#__PURE__*/React.createElement(DS_H.Avatar, {
    name: f.who,
    size: 28
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: 13,
      color: 'var(--text-secondary)',
      lineHeight: 1.4
    }
  }, /*#__PURE__*/React.createElement("b", {
    style: {
      color: 'var(--text-primary)',
      fontWeight: 600
    }
  }, f.who), " ", f.what), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 11,
      color: 'var(--text-muted)',
      marginTop: 2
    }
  }, f.t)))))), /*#__PURE__*/React.createElement(DS_H.Dialog, {
    open: dlg,
    title: "New task",
    onClose: () => setDlg(false),
    footer: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(DS_H.Button, {
      variant: "secondary",
      onClick: () => setDlg(false)
    }, "Cancel"), /*#__PURE__*/React.createElement(DS_H.Button, {
      onClick: () => setDlg(false)
    }, "Create task"))
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 14
    }
  }, /*#__PURE__*/React.createElement(DS_H.Input, {
    label: "Description",
    placeholder: "Edit Aurora Cafe reel"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement(DS_H.Select, {
    label: "Client",
    options: ['Aurora Cafe', 'Lumen Realty', 'Verde Fitness']
  }), /*#__PURE__*/React.createElement(DS_H.Input, {
    label: "Deadline",
    mono: true,
    placeholder: "2025-06-09"
  })))));
}
window.HomeScreen = HomeScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/portal/HomeScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/portal/LoginScreen.jsx
try { (() => {
/* Login screen — dark, centred, gold CTA. Google sign-in + MFA hint. */
const DS_L = window.SkalyPortalDesignSystem_a5ef85;
function LoginScreen({
  onLogin
}) {
  const {
    Icon
  } = window.PortalShell;
  const [email, setEmail] = React.useState('naaz@skalygroup.com');
  const [pw, setPw] = React.useState('••••••••••');
  return /*#__PURE__*/React.createElement("div", {
    style: {
      minHeight: '100%',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      background: 'radial-gradient(120% 90% at 50% 0%, #161318 0%, var(--bg-base) 60%)',
      padding: 24
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 380
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      gap: 14,
      marginBottom: 28
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/skaly-mark.svg",
    width: "52",
    height: "52",
    alt: "Skaly",
    style: {
      borderRadius: 14
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 800,
      fontSize: 30,
      color: 'var(--text-primary)',
      lineHeight: 1.1
    }
  }, "Welcome back"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: 14,
      color: 'var(--text-muted)',
      marginTop: 4
    }
  }, "Sign in to the Skaly Business Portal"))), /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--bg-elevated)',
      border: '1px solid var(--border-subtle)',
      borderRadius: 'var(--radius)',
      padding: 24,
      display: 'flex',
      flexDirection: 'column',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement(DS_L.Input, {
    label: "Email",
    value: email,
    onChange: e => setEmail(e.target.value),
    iconLeft: /*#__PURE__*/React.createElement(Icon, {
      name: "mail",
      size: 16
    })
  }), /*#__PURE__*/React.createElement(DS_L.Input, {
    label: "Password",
    type: "password",
    value: pw,
    onChange: e => setPw(e.target.value),
    iconLeft: /*#__PURE__*/React.createElement(Icon, {
      name: "lock",
      size: 16
    })
  }), /*#__PURE__*/React.createElement(DS_L.Button, {
    fullWidth: true,
    onClick: onLogin
  }, "Sign in"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12,
      color: 'var(--text-disabled)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      height: 1,
      background: 'var(--border-subtle)'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 11
    }
  }, "OR"), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      height: 1,
      background: 'var(--border-subtle)'
    }
  })), /*#__PURE__*/React.createElement(DS_L.Button, {
    variant: "secondary",
    fullWidth: true,
    iconLeft: /*#__PURE__*/React.createElement(Icon, {
      name: "chrome",
      size: 16
    }),
    onClick: onLogin
  }, "Continue with Google")), /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'center',
      marginTop: 18,
      fontFamily: 'var(--font-body)',
      fontSize: 13,
      color: 'var(--text-muted)'
    }
  }, "No account? ", /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--accent-gold)',
      cursor: 'pointer'
    }
  }, "Request access"))));
}
window.LoginScreen = LoginScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/portal/LoginScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/portal/Shell.jsx
try { (() => {
/* Portal shell: Icon helper, Sidebar, Topbar, and the app frame.
   Composes SidebarNav / PeriodSelector / IconButton / Badge from the bundle. */
const DS = window.SkalyPortalDesignSystem_a5ef85;

/* ---- Lucide icon (vanilla createIcons into a ref) ---- */
function Icon({
  name,
  size = 20,
  color
}) {
  const ref = React.useRef(null);
  React.useEffect(() => {
    if (!ref.current || !window.lucide) return;
    ref.current.innerHTML = `<i data-lucide="${name}"></i>`;
    window.lucide.createIcons({
      attrs: {
        width: size,
        height: size,
        stroke: color || 'currentColor'
      }
    });
  }, [name, size, color]);
  return /*#__PURE__*/React.createElement("span", {
    ref: ref,
    style: {
      display: 'inline-flex',
      alignItems: 'center'
    }
  });
}
const NAV = [{
  id: 'home',
  label: 'Home',
  icon: 'house'
}, {
  id: 'attendance',
  label: 'Attendance',
  icon: 'user-check'
}, {
  id: 'tasks',
  label: 'Tasks',
  icon: 'square-check-big',
  badge: 12
}, {
  id: 'planner',
  label: 'Shoot Planner',
  icon: 'camera'
}, {
  id: 'dropper',
  label: 'Content Dropper',
  icon: 'upload'
}, {
  id: 'calendar',
  label: 'Content Calendar',
  icon: 'calendar'
}, {
  id: 'chat',
  label: 'Common Chat',
  icon: 'message-square',
  badge: 3
}, {
  id: 'bot',
  label: 'AI Bot',
  icon: 'sparkles'
}];
function Logo() {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/skaly-mark.svg",
    width: "26",
    height: "26",
    alt: "",
    style: {
      borderRadius: 7
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 800,
      fontSize: 18,
      letterSpacing: '.04em',
      color: 'var(--accent-gold)'
    }
  }, "SKALY")), /*#__PURE__*/React.createElement(DS.PeriodSelector, {
    period: "June 2025",
    onClick: () => {}
  }));
}
function Sidebar({
  active,
  onSelect,
  user
}) {
  const items = NAV.map(n => ({
    ...n,
    icon: /*#__PURE__*/React.createElement(Icon, {
      name: n.icon,
      size: 20
    })
  }));
  return /*#__PURE__*/React.createElement(DS.SidebarNav, {
    items: items,
    activeId: active,
    onSelect: onSelect,
    header: /*#__PURE__*/React.createElement(Logo, null),
    footer: /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 10
      }
    }, /*#__PURE__*/React.createElement(DS.Avatar, {
      name: user.name,
      size: 32
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        lineHeight: 1.3,
        minWidth: 0
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 13,
        fontWeight: 600,
        color: 'var(--text-primary)',
        whiteSpace: 'nowrap',
        overflow: 'hidden',
        textOverflow: 'ellipsis'
      }
    }, user.name), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 11,
        color: 'var(--text-muted)'
      }
    }, user.role)))
  });
}
function Topbar({
  title,
  onSearch,
  onLogout
}) {
  return /*#__PURE__*/React.createElement("header", {
    style: {
      height: 56,
      flexShrink: 0,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      padding: '0 20px',
      background: 'var(--bg-surface)',
      borderBottom: '1px solid var(--border-subtle)'
    }
  }, /*#__PURE__*/React.createElement("h1", {
    style: {
      margin: 0,
      fontFamily: 'var(--font-display)',
      fontWeight: 700,
      fontSize: 24,
      color: 'var(--text-primary)'
    }
  }, title), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("button", {
    onClick: onSearch,
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      height: 36,
      padding: '0 10px 0 12px',
      background: 'var(--bg-elevated)',
      border: '1px solid var(--border-default)',
      borderRadius: 'var(--radius-md)',
      cursor: 'pointer',
      color: 'var(--text-muted)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "search",
    size: 16
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: 13
    }
  }, "Search\u2026"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 11,
      padding: '1px 5px',
      borderRadius: 4,
      background: 'var(--bg-hover)',
      color: 'var(--text-secondary)'
    }
  }, "\u2318K")), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement(DS.IconButton, {
    label: "Notifications"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "bell",
    size: 20
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      top: 2,
      right: 2,
      width: 8,
      height: 8,
      borderRadius: '50%',
      background: 'var(--accent-gold)',
      border: '2px solid var(--bg-surface)'
    }
  })), /*#__PURE__*/React.createElement(DS.IconButton, {
    label: "Sign out",
    onClick: onLogout
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "log-out",
    size: 20
  }))));
}
window.PortalShell = {
  Icon,
  Sidebar,
  Topbar,
  NAV
};
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/portal/Shell.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Avatar = __ds_scope.Avatar;

__ds_ns.AvatarStack = __ds_scope.AvatarStack;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.Checkbox = __ds_scope.Checkbox;

__ds_ns.IconButton = __ds_scope.IconButton;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.Select = __ds_scope.Select;

__ds_ns.Switch = __ds_scope.Switch;

__ds_ns.Tabs = __ds_scope.Tabs;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Tag = __ds_scope.Tag;

__ds_ns.Dialog = __ds_scope.Dialog;

__ds_ns.EmptyState = __ds_scope.EmptyState;

__ds_ns.StatusChip = __ds_scope.StatusChip;

__ds_ns.Toast = __ds_scope.Toast;

__ds_ns.Tooltip = __ds_scope.Tooltip;

__ds_ns.PeriodSelector = __ds_scope.PeriodSelector;

__ds_ns.SidebarNav = __ds_scope.SidebarNav;

})();
