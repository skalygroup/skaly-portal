import React from 'react';

/**
 * StatusChip — the portal's core status token. Background is the status
 * colour @ 15%, text @ 100%. Cancelled is struck through. Some statuses
 * render no chip (No Activity / Unset) — handle that at the call site.
 */
const STATUS = {
  // label: [colorVar, bgVar, strike?]
  'Under Progress': ['--status-blue',  '--status-blue-bg'],
  'In Progress':    ['--status-blue',  '--status-blue-bg'],
  'Scheduled':      ['--status-blue',  '--status-blue-bg'],
  'Ready':          ['--status-teal',  '--status-teal-bg'],
  'Posted':         ['--status-gold',  '--accent-gold-15'],
  'Confirmed':      ['--status-gold',  '--accent-gold-15'],
  'Pending':        ['--status-amber', '--status-amber-bg'],
  'Awaiting':       ['--status-amber', '--status-amber-bg'],
  'Done':           ['--status-green', '--status-green-bg'],
  'Completed':      ['--status-green', '--status-green-bg'],
  'Blocked':        ['--status-red',   '--status-red-bg'],
  'Overdue':        ['--status-red',   '--status-red-bg'],
  'Failed':         ['--status-red',   '--status-red-bg'],
  'To Do':          ['--status-grey',  '--status-grey-bg'],
  'Rescheduled':    ['--status-grey',  '--status-grey-bg'],
  'Cancelled':      ['--status-grey',  '--status-grey-bg', true],
  'Locked':         ['--status-grey',  '--status-grey-bg'],
};

export function StatusChip({ status, label, dot = false, trigger = false, style = {} }) {
  const key = status || label;
  const entry = STATUS[key] || ['--status-grey', '--status-grey-bg'];
  const [color, bg, strike] = entry;

  return (
    <span style={{
      position: 'relative',
      display: 'inline-flex', alignItems: 'center', gap: 6,
      height: 24, padding: '0 10px',
      borderRadius: 'var(--radius-md)',
      background: `var(${bg})`,
      color: `var(${color})`,
      fontFamily: 'var(--font-body)', fontSize: 12, fontWeight: 500,
      textDecoration: strike ? 'line-through' : 'none',
      whiteSpace: 'nowrap',
      ...style,
    }}>
      {dot && <span style={{ width: 6, height: 6, borderRadius: '50%', background: `var(${color})` }} />}
      {key}
      {trigger && (
        <span title="Auto-updated from Content Dropper" style={{
          position: 'absolute', top: -3, right: -3,
          width: 6, height: 6, borderRadius: '50%', background: 'var(--accent-gold)',
        }} />
      )}
    </span>
  );
}
