import React from 'react';

/** EmptyState — Big Shoulders headline + helper text + optional CTA. */
export function EmptyState({ icon, title = 'Nothing here yet', message, action, style = {} }) {
  return (
    <div style={{
      display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
      textAlign: 'center', gap: 8, padding: '48px 24px',
      ...style,
    }}>
      {icon && <div style={{ color: 'var(--text-disabled)', marginBottom: 4 }}>{icon}</div>}
      <h3 style={{
        margin: 0, fontFamily: 'var(--font-display)', fontWeight: 600,
        fontSize: 24, color: 'var(--text-secondary)',
      }}>{title}</h3>
      {message && (
        <p style={{ margin: 0, maxWidth: 320, fontFamily: 'var(--font-body)', fontSize: 14, color: 'var(--text-muted)', lineHeight: 1.5 }}>{message}</p>
      )}
      {action && <div style={{ marginTop: 12 }}>{action}</div>}
    </div>
  );
}
