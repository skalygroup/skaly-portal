`Badge` is a small count pill (gold for unread notification counts, "99+" in DM Mono). `Tag` is an outlined role/category label.

```jsx
<Badge variant="gold">12</Badge>
<Badge variant="red">3</Badge>
<Tag>Manager</Tag>
<Tag color="#3B82F6">Priority</Tag>
```
