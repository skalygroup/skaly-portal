import { ReactNode, CSSProperties } from 'react';

export interface EmptyStateProps {
  /** Optional Lucide icon node (large, muted). */
  icon?: ReactNode;
  /** @default "Nothing here yet" */
  title?: string;
  message?: string;
  /** Optional CTA node. */
  action?: ReactNode;
  style?: CSSProperties;
}

/** Empty-grid / no-results state — Big Shoulders headline + helper + CTA. */
export function EmptyState(props: EmptyStateProps): JSX.Element;
