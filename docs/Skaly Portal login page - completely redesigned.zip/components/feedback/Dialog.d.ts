import { ReactNode } from 'react';

export interface DialogProps {
  /** @default true */
  open?: boolean;
  title?: string;
  children?: ReactNode;
  /** Footer actions (usually Button nodes, right-aligned). */
  footer?: ReactNode;
  onClose?: () => void;
  /** Max width px. @default 440 */
  width?: number;
}

/** Modal dialog over a blurred backdrop. Closes on Escape / backdrop / button. */
export function Dialog(props: DialogProps): JSX.Element | null;
