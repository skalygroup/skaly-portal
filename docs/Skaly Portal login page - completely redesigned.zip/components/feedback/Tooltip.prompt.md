Dark hover/focus tooltip. Used for trigger-source hints ("Set by Shoot Planner"), locked-cell explanations, icon labels.

```jsx
<Tooltip content="Auto-updated from Content Dropper">
  <StatusChip status="Posted" trigger />
</Tooltip>
```

`side`: top (default) / bottom / left / right.
