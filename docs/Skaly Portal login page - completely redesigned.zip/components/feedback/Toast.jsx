import React from 'react';

/** Toast — bottom-right notification. Variants map to status colours. */
export function Toast({ title, message, variant = 'info', action, onClose, style = {} }) {
  const accent = {
    info:    'var(--accent-gold)',
    success: 'var(--status-green)',
    error:   'var(--status-red)',
    warning: 'var(--status-amber)',
  }[variant] || 'var(--accent-gold)';

  return (
    <div role="status" style={{
      display: 'flex', alignItems: 'flex-start', gap: 12,
      width: 340, padding: '14px 16px',
      background: 'var(--bg-elevated)',
      border: '1px solid var(--border-default)',
      borderLeft: `3px solid ${accent}`,
      borderRadius: 'var(--radius-md)',
      boxShadow: 'var(--shadow-lg)',
      ...style,
    }}>
      <div style={{ flex: 1, minWidth: 0 }}>
        {title && <div style={{ fontFamily: 'var(--font-body)', fontSize: 14, fontWeight: 600, color: 'var(--text-primary)' }}>{title}</div>}
        {message && <div style={{ fontFamily: 'var(--font-body)', fontSize: 13, color: 'var(--text-secondary)', marginTop: 2 }}>{message}</div>}
        {action && <div style={{ marginTop: 10 }}>{action}</div>}
      </div>
      {onClose && (
        <button onClick={onClose} aria-label="Dismiss" style={{ background: 'transparent', border: 'none', cursor: 'pointer', color: 'var(--text-muted)', padding: 2, display: 'inline-flex' }}>
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
        </button>
      )}
    </div>
  );
}
