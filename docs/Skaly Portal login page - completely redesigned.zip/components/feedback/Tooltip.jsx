import React from 'react';

/** Tooltip — dark elevated bubble on hover/focus. */
export function Tooltip({ children, content, side = 'top', style = {} }) {
  const [open, setOpen] = React.useState(false);
  const pos = {
    top:    { bottom: '100%', left: '50%', transform: 'translateX(-50%)', marginBottom: 8 },
    bottom: { top: '100%', left: '50%', transform: 'translateX(-50%)', marginTop: 8 },
    left:   { right: '100%', top: '50%', transform: 'translateY(-50%)', marginRight: 8 },
    right:  { left: '100%', top: '50%', transform: 'translateY(-50%)', marginLeft: 8 },
  };
  return (
    <span
      style={{ position: 'relative', display: 'inline-flex' }}
      onMouseEnter={() => setOpen(true)}
      onMouseLeave={() => setOpen(false)}
      onFocus={() => setOpen(true)}
      onBlur={() => setOpen(false)}
    >
      {children}
      {open && (
        <span role="tooltip" style={{
          position: 'absolute', zIndex: 100,
          ...pos[side],
          padding: '6px 10px',
          background: 'var(--bg-elevated)',
          border: '1px solid var(--border-default)',
          borderRadius: 'var(--radius-sm)',
          boxShadow: 'var(--shadow-md)',
          color: 'var(--text-primary)',
          fontFamily: 'var(--font-body)', fontSize: 12, fontWeight: 500,
          whiteSpace: 'nowrap', pointerEvents: 'none',
          ...style,
        }}>{content}</span>
      )}
    </span>
  );
}
