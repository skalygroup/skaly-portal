import { ReactNode, CSSProperties } from 'react';

export interface ToastProps {
  title?: string;
  message?: string;
  /** @default "info" */
  variant?: 'info' | 'success' | 'error' | 'warning';
  /** Optional action node (e.g. a "Retry" Button). */
  action?: ReactNode;
  onClose?: () => void;
  style?: CSSProperties;
}

/** Bottom-right toast with a status-coloured left accent. */
export function Toast(props: ToastProps): JSX.Element;
