Bottom-right notification with a status-coloured left accent. Used for save failures, retries, optimistic-update reverts.

```jsx
<Toast variant="error" title="Failed to save" message="Try again."
  action={<Button size="sm" variant="secondary">Retry</Button>}
  onClose={dismiss} />
<Toast variant="success" title="Holiday added" />
```

Variants: info (gold), success (green), error (red), warning (amber).
