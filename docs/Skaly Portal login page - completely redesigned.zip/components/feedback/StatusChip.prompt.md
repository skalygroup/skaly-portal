The portal's core status token. Background is the status colour at 15%, text at 100%. Used in every grid (calendar, tasks, planner, dropper).

```jsx
<StatusChip status="Posted" />
<StatusChip status="Under Progress" dot />
<StatusChip status="Posted" trigger />   {/* gold dot = pipeline-triggered */}
<StatusChip status="Cancelled" />         {/* strikethrough */}
```

Colour map: blue = In Progress/Scheduled, teal = Ready, gold = Posted/Confirmed, amber = Pending, green = Done/Completed, red = Blocked/Overdue, grey = To Do/Rescheduled/Cancelled. **"No Activity" and "Unset" render NO chip** — don't pass them; leave the cell empty or dashed instead.
