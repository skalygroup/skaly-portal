import React from 'react';

/** Badge — small count / label pill. Gold variant for unread counts. */
export function Badge({ children, variant = 'neutral', mono = true, style = {} }) {
  const variants = {
    neutral: { background: 'var(--bg-hover)', color: 'var(--text-secondary)' },
    gold:    { background: 'var(--accent-gold)', color: 'var(--bg-base)' },
    outline: { background: 'transparent', color: 'var(--text-secondary)', border: '1px solid var(--border-default)' },
    red:     { background: 'var(--status-red)', color: 'var(--text-primary)' },
  };
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
      minWidth: 18, height: 18, padding: '0 6px',
      borderRadius: 'var(--radius-full)',
      fontFamily: mono ? 'var(--font-mono)' : 'var(--font-body)',
      fontSize: 11, fontWeight: 600, lineHeight: 1,
      ...(variants[variant] || variants.neutral),
      ...style,
    }}>{children}</span>
  );
}

/** Role / category tag — outlined pill in DM Sans. */
export function Tag({ children, color, style = {} }) {
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center',
      height: 22, padding: '0 10px',
      borderRadius: 'var(--radius-full)',
      border: `1px solid ${color ? color : 'var(--border-default)'}`,
      background: color ? `${color}1f` : 'var(--bg-elevated)',
      color: color || 'var(--text-secondary)',
      fontFamily: 'var(--font-body)', fontSize: 12, fontWeight: 500,
      whiteSpace: 'nowrap',
      ...style,
    }}>{children}</span>
  );
}
