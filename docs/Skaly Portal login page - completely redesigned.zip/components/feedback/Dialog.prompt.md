Modal dialog over a blurred dark backdrop (scale-in 180ms). Closes on Escape, backdrop click, or close button.

```jsx
<Dialog open={open} title="Add holiday" onClose={close}
  footer={<>
    <Button variant="secondary" onClick={close}>Cancel</Button>
    <Button onClick={save}>Add holiday</Button>
  </>}>
  <Input label="Date" mono placeholder="2025-06-21" />
</Dialog>
```

Used for quick-action modals, confirmations, "Shall I proceed?" bot turns.
