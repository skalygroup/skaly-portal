Empty-grid / no-results state. Big Shoulders headline, DM Sans helper, optional CTA.

```jsx
<EmptyState icon={<Inbox size={40} strokeWidth={1.5}/>}
  title="No tasks today"
  message="Tasks assigned to you will show up here."
  action={<Button>+ Add task</Button>} />
```
