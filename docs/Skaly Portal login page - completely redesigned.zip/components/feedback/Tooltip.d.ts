import { ReactNode, CSSProperties } from 'react';

export interface TooltipProps {
  /** Trigger element. */
  children?: ReactNode;
  /** Tooltip content. */
  content?: ReactNode;
  /** @default "top" */
  side?: 'top' | 'bottom' | 'left' | 'right';
  style?: CSSProperties;
}

/** Hover/focus tooltip — dark elevated bubble. */
export function Tooltip(props: TooltipProps): JSX.Element;
