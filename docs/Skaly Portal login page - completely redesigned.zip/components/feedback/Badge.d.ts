import { ReactNode, CSSProperties } from 'react';

export interface BadgeProps {
  children?: ReactNode;
  /** gold = unread count; red = alert. @default "neutral" */
  variant?: 'neutral' | 'gold' | 'outline' | 'red';
  /** Render in DM Mono (good for counts). @default true */
  mono?: boolean;
  style?: CSSProperties;
}

export interface TagProps {
  children?: ReactNode;
  /** Optional hex colour to tint border/bg/text (e.g. a status colour). */
  color?: string;
  style?: CSSProperties;
}

/** Small count/label pill — gold for unread counts (e.g. notifications). */
export function Badge(props: BadgeProps): JSX.Element;
/** Outlined category/role tag in DM Sans. */
export function Tag(props: TagProps): JSX.Element;
