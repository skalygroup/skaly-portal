import { CSSProperties } from 'react';

export type StatusLabel =
  | 'Under Progress' | 'In Progress' | 'Scheduled'
  | 'Ready' | 'Posted' | 'Confirmed'
  | 'Pending' | 'Awaiting'
  | 'Done' | 'Completed'
  | 'Blocked' | 'Overdue' | 'Failed'
  | 'To Do' | 'Rescheduled' | 'Cancelled' | 'Locked';

export interface StatusChipProps {
  /** Status label (drives colour). */
  status?: StatusLabel;
  /** Alias for status. */
  label?: StatusLabel;
  /** Show a leading status dot. */
  dot?: boolean;
  /** Gold dot at top-right — set by a pipeline trigger. */
  trigger?: boolean;
  style?: CSSProperties;
}

/**
 * Status chip — colour @15% bg, text @100%. Blue=in-progress, teal=ready,
 * gold=posted/confirmed, amber=pending, green=done, red=blocked, grey=to-do/
 * cancelled (struck through). "No Activity" / "Unset" render no chip.
 *
 * @startingPoint section="Feedback" subtitle="Full portal status chip set" viewport="700x160"
 */
export function StatusChip(props: StatusChipProps): JSX.Element;
