import React from 'react';

/** Tabs — underline-style. Active tab text + indicator are gold. */
export function Tabs({ tabs = [], value, defaultValue, onChange, style = {} }) {
  const items = tabs.map((t) => (typeof t === 'string' ? { value: t, label: t } : t));
  const isControlled = value !== undefined;
  const [internal, setInternal] = React.useState(defaultValue ?? (items[0] && items[0].value));
  const active = isControlled ? value : internal;
  const select = (v) => { if (!isControlled) setInternal(v); onChange && onChange(v); };

  return (
    <div style={{ display: 'flex', gap: 4, borderBottom: '1px solid var(--border-subtle)', ...style }}>
      {items.map((t) => {
        const on = t.value === active;
        return (
          <button
            key={t.value}
            type="button"
            onClick={() => select(t.value)}
            style={{
              position: 'relative',
              padding: '10px 14px',
              background: 'transparent', border: 'none', cursor: 'pointer',
              fontFamily: 'var(--font-body)', fontSize: 14,
              fontWeight: on ? 600 : 500,
              color: on ? 'var(--accent-gold)' : 'var(--text-secondary)',
              transition: 'color 120ms ease',
              display: 'inline-flex', alignItems: 'center', gap: 8,
            }}
          >
            {t.label}
            {t.count != null && (
              <span style={{
                fontFamily: 'var(--font-mono)', fontSize: 11,
                padding: '1px 6px', borderRadius: 'var(--radius-full)',
                background: on ? 'var(--accent-gold-15)' : 'var(--bg-hover)',
                color: on ? 'var(--accent-gold)' : 'var(--text-muted)',
              }}>{t.count}</span>
            )}
            <span style={{
              position: 'absolute', left: 0, right: 0, bottom: -1, height: 2,
              background: on ? 'var(--accent-gold)' : 'transparent',
              transition: 'background 120ms ease',
            }} />
          </button>
        );
      })}
    </div>
  );
}
