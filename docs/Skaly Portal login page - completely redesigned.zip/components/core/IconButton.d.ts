import { ReactNode, CSSProperties, MouseEventHandler } from 'react';

export interface IconButtonProps {
  /** A Lucide icon node (20px). */
  children?: ReactNode;
  /** @default "md" */
  size?: 'sm' | 'md' | 'lg';
  /** @default "ghost" */
  variant?: 'ghost' | 'outline';
  /** Active/selected state — icon turns gold. */
  active?: boolean;
  disabled?: boolean;
  /** Accessible label (also used as title). */
  label?: string;
  onClick?: MouseEventHandler<HTMLButtonElement>;
  style?: CSSProperties;
}

/** Square icon-only button for topbar/toolbar/row actions. */
export function IconButton(props: IconButtonProps): JSX.Element;
