import { CSSProperties } from 'react';

export interface AvatarProps {
  /** Used for initials fallback and deterministic colour. */
  name?: string;
  src?: string;
  /** Diameter in px. @default 32 */
  size?: number;
  style?: CSSProperties;
}

export interface Person { name: string; src?: string; }

export interface AvatarStackProps {
  /** Array of names or {name,src}. */
  people?: (string | Person)[];
  /** @default 28 */
  size?: number;
  /** Max avatars before "+N". @default 4 */
  max?: number;
}

/** Circular avatar with image or coloured initials fallback. */
export function Avatar(props: AvatarProps): JSX.Element;
/** Overlapping avatar stack for assignee lists. */
export function AvatarStack(props: AvatarStackProps): JSX.Element;
