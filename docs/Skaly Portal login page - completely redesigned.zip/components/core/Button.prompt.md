Gold action button — the only filled colour in the portal; one gold CTA per view, everything else secondary/ghost.

```jsx
<Button variant="primary" onClick={save}>Save changes</Button>
<Button variant="secondary">Cancel</Button>
<Button variant="ghost" size="sm">Skip</Button>
<Button variant="destructive">Delete</Button>
```

Variants: `primary` (gold), `secondary` (dark outline), `ghost` (transparent), `destructive` (red tint). Sizes: `sm` 32px, `md` 40px, `lg` 44px. Pass `iconLeft` / `iconRight` (Lucide nodes), `fullWidth`, `disabled`. Hover lightens gold; press scales 0.97.
