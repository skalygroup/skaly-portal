import { ReactNode, CSSProperties, MouseEventHandler } from 'react';

export interface ButtonProps {
  children?: ReactNode;
  /** primary = gold filled (the only filled CTA). @default "primary" */
  variant?: 'primary' | 'secondary' | 'ghost' | 'destructive';
  /** @default "md" */
  size?: 'sm' | 'md' | 'lg';
  disabled?: boolean;
  iconLeft?: ReactNode;
  iconRight?: ReactNode;
  fullWidth?: boolean;
  type?: 'button' | 'submit' | 'reset';
  onClick?: MouseEventHandler<HTMLButtonElement>;
  style?: CSSProperties;
}

/**
 * Primary action button. Gold filled = the single CTA per view; use
 * secondary/ghost for everything else (60/30/10 rule).
 *
 * @startingPoint section="Core" subtitle="Gold CTA + secondary/ghost variants" viewport="700x180"
 */
export function Button(props: ButtonProps): JSX.Element;
