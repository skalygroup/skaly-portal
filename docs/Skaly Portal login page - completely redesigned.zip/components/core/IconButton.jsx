import React from 'react';

/**
 * IconButton — square icon-only control for toolbars, topbars,
 * row actions. Pass a Lucide icon node as children.
 */
export function IconButton({
  children,
  size = 'md',
  variant = 'ghost',
  active = false,
  disabled = false,
  label,
  onClick,
  style = {},
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const dim = { sm: 32, md: 36, lg: 44 }[size] || 36;

  const variants = {
    ghost: {
      background: active ? 'var(--bg-selected)' : hover ? 'var(--bg-hover)' : 'transparent',
      color: active ? 'var(--accent-gold)' : 'var(--text-secondary)',
      border: '1px solid transparent',
    },
    outline: {
      background: hover ? 'var(--bg-hover)' : 'var(--bg-elevated)',
      color: 'var(--text-primary)',
      border: '1px solid var(--border-default)',
    },
  };

  return (
    <button
      type="button"
      aria-label={label}
      title={label}
      disabled={disabled}
      onClick={onClick}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        justifyContent: 'center',
        width: dim,
        height: dim,
        borderRadius: 'var(--radius-md)',
        cursor: disabled ? 'not-allowed' : 'pointer',
        opacity: disabled ? 0.4 : 1,
        transition: 'background 120ms ease, color 120ms ease',
        ...(variants[variant] || variants.ghost),
        ...style,
      }}
      {...rest}
    >
      {children}
    </button>
  );
}
