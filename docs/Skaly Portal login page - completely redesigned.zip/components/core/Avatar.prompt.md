Circular avatar with image or deterministic coloured initials. `AvatarStack` overlaps several with a `+N` overflow — used for task assignees.

```jsx
<Avatar name="Naaz Khan" size={32} />
<Avatar name="Sohail" src="/team/sohail.jpg" />
<AvatarStack people={['Naaz Khan','Sohail','Aman','Priya','Ravi']} max={4} />
```

Colour is derived from the name. Sizes are free (px).
