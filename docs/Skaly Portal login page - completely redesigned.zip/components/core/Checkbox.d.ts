import { CSSProperties } from 'react';

export interface CheckboxProps {
  checked?: boolean;
  defaultChecked?: boolean;
  disabled?: boolean;
  onChange?: (next: boolean) => void;
  label?: string;
  style?: CSSProperties;
}

/** Checkbox — gold fill with dark checkmark when on. */
export function Checkbox(props: CheckboxProps): JSX.Element;
