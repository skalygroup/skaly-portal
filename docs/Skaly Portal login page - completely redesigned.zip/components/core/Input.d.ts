import { ReactNode, CSSProperties, ChangeEventHandler } from 'react';

export interface InputProps {
  label?: string;
  value?: string;
  defaultValue?: string;
  placeholder?: string;
  /** @default "text" */
  type?: string;
  iconLeft?: ReactNode;
  /** Render value in DM Mono — use for IDs, periods, numeric data. */
  mono?: boolean;
  disabled?: boolean;
  error?: boolean;
  /** Helper / error text below the field. */
  hint?: string;
  onChange?: ChangeEventHandler<HTMLInputElement>;
  id?: string;
  style?: CSSProperties;
}

/** Dark text input with gold focus ring. */
export function Input(props: InputProps): JSX.Element;
