import React from 'react';

/** Card — elevated dark surface. Optional header (title + action) and padding control. */
export function Card({ children, title, action, padding = 16, elevated = false, style = {}, ...rest }) {
  return (
    <div
      style={{
        background: 'var(--bg-elevated)',
        border: '1px solid var(--border-subtle)',
        borderRadius: 'var(--radius)',
        boxShadow: elevated ? 'var(--shadow-md)' : 'none',
        overflow: 'hidden',
        ...style,
      }}
      {...rest}
    >
      {(title || action) && (
        <div style={{
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          padding: `14px ${padding}px`,
          borderBottom: '1px solid var(--border-subtle)',
        }}>
          {title && (
            <h3 style={{
              margin: 0, fontFamily: 'var(--font-display)', fontWeight: 600,
              fontSize: 20, color: 'var(--text-primary)', letterSpacing: '0.01em',
            }}>{title}</h3>
          )}
          {action}
        </div>
      )}
      <div style={{ padding }}>{children}</div>
    </div>
  );
}
