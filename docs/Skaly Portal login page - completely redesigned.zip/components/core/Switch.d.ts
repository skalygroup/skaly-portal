import { CSSProperties } from 'react';

export interface SwitchProps {
  /** Controlled on/off. Omit for uncontrolled (use defaultChecked). */
  checked?: boolean;
  defaultChecked?: boolean;
  disabled?: boolean;
  onChange?: (next: boolean) => void;
  /** Optional inline label to the right. */
  label?: string;
  style?: CSSProperties;
}

/** Toggle switch — track turns gold when on. */
export function Switch(props: SwitchProps): JSX.Element;
