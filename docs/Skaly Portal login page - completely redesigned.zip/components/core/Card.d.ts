import { ReactNode, CSSProperties } from 'react';

export interface CardProps {
  children?: ReactNode;
  /** Optional header title (Big Shoulders 20px). */
  title?: string;
  /** Optional header action node (button, menu) shown at right. */
  action?: ReactNode;
  /** Body padding in px. @default 16 */
  padding?: number;
  /** Add a drop shadow (use for floating/important cards). */
  elevated?: boolean;
  style?: CSSProperties;
}

/** Elevated dark surface card with optional titled header. */
export function Card(props: CardProps): JSX.Element;
