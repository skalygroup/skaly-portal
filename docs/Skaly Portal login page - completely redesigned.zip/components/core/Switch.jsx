import React from 'react';

/** Switch — gold when on. Used for toggles, attendance, preferences. */
export function Switch({ checked, defaultChecked = false, disabled = false, onChange, label, style = {} }) {
  const isControlled = checked !== undefined;
  const [internal, setInternal] = React.useState(defaultChecked);
  const on = isControlled ? checked : internal;

  const toggle = () => {
    if (disabled) return;
    if (!isControlled) setInternal(!on);
    onChange && onChange(!on);
  };

  const knob = (
    <button
      type="button"
      role="switch"
      aria-checked={on}
      aria-label={label}
      disabled={disabled}
      onClick={toggle}
      style={{
        position: 'relative',
        width: 40, height: 24, flexShrink: 0,
        borderRadius: 'var(--radius-full)',
        border: 'none',
        background: on ? 'var(--accent-gold)' : 'var(--bg-hover)',
        cursor: disabled ? 'not-allowed' : 'pointer',
        opacity: disabled ? 0.5 : 1,
        transition: 'background 150ms ease',
        padding: 0,
        ...style,
      }}
    >
      <span style={{
        position: 'absolute', top: 2, left: on ? 18 : 2,
        width: 20, height: 20, borderRadius: '50%',
        background: on ? 'var(--bg-base)' : 'var(--text-secondary)',
        transition: 'left 150ms cubic-bezier(0.16,1,0.3,1), background 150ms ease',
      }} />
    </button>
  );

  if (!label) return knob;
  return (
    <label style={{ display: 'inline-flex', alignItems: 'center', gap: 10, cursor: disabled ? 'not-allowed' : 'pointer' }}>
      {knob}
      <span style={{ fontFamily: 'var(--font-body)', fontSize: 14, color: 'var(--text-primary)' }}>{label}</span>
    </label>
  );
}
