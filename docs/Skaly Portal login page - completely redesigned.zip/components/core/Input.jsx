import React from 'react';

/**
 * Input — dark text field. Optional leading icon and label.
 * Focus ring is gold per a11y spec.
 */
export function Input({
  label,
  value,
  defaultValue,
  placeholder,
  type = 'text',
  iconLeft = null,
  mono = false,
  disabled = false,
  error = false,
  hint,
  onChange,
  style = {},
  id,
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  const reactId = React.useId();
  const inputId = id || reactId;

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 6, width: '100%' }}>
      {label && (
        <label htmlFor={inputId} style={{
          fontFamily: 'var(--font-body)', fontSize: 13, fontWeight: 600,
          color: 'var(--text-primary)',
        }}>{label}</label>
      )}
      <div style={{
        display: 'flex', alignItems: 'center', gap: 8,
        height: 40, padding: '0 12px',
        background: 'var(--bg-elevated)',
        border: `1px solid ${error ? 'var(--status-red)' : focus ? 'var(--accent-gold)' : 'var(--border-default)'}`,
        borderRadius: 'var(--radius-md)',
        boxShadow: focus ? '0 0 0 2px var(--accent-gold-dim)' : 'none',
        opacity: disabled ? 0.5 : 1,
        transition: 'border-color 120ms ease, box-shadow 120ms ease',
      }}>
        {iconLeft && <span style={{ color: 'var(--text-muted)', display: 'inline-flex' }}>{iconLeft}</span>}
        <input
          id={inputId}
          type={type}
          value={value}
          defaultValue={defaultValue}
          placeholder={placeholder}
          disabled={disabled}
          onChange={onChange}
          onFocus={() => setFocus(true)}
          onBlur={() => setFocus(false)}
          style={{
            flex: 1, minWidth: 0, height: '100%',
            background: 'transparent', border: 'none', outline: 'none',
            color: 'var(--text-primary)',
            fontFamily: mono ? 'var(--font-mono)' : 'var(--font-body)',
            fontSize: mono ? 13 : 14,
            ...style,
          }}
          {...rest}
        />
      </div>
      {hint && (
        <span style={{
          fontFamily: 'var(--font-body)', fontSize: 12,
          color: error ? 'var(--status-red)' : 'var(--text-muted)',
        }}>{hint}</span>
      )}
    </div>
  );
}
