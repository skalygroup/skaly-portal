Dark dropdown matching the Input style, with a custom chevron and gold focus ring.

```jsx
<Select label="Role" placeholder="Select role"
  options={['Admin', 'Manager', 'Team Member', 'Freelancer']} />
<Select label="Status" value={status} onChange={e => setStatus(e.target.value)}
  options={[{value:'todo',label:'To Do'},{value:'done',label:'Done'}]} />
```

Accepts string[] or {value,label}[]. Use `mono` for data-style values.
