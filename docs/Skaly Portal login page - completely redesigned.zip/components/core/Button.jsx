import React from 'react';

/**
 * Skaly Button — gold = action. 60/30/10: gold primary is the only
 * filled colour in the UI; everything else is dark/outline/ghost.
 */
export function Button({
  children,
  variant = 'primary',
  size = 'md',
  disabled = false,
  iconLeft = null,
  iconRight = null,
  fullWidth = false,
  type = 'button',
  onClick,
  style = {},
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const [active, setActive] = React.useState(false);

  const sizes = {
    sm: { height: 32, padding: '0 12px', font: 13 },
    md: { height: 40, padding: '0 16px', font: 14 },
    lg: { height: 44, padding: '0 24px', font: 15 },
  };
  const s = sizes[size] || sizes.md;

  const base = {
    display: 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    height: s.height,
    padding: s.padding,
    width: fullWidth ? '100%' : 'auto',
    fontFamily: 'var(--font-body)',
    fontSize: s.font,
    fontWeight: 600,
    lineHeight: 1,
    borderRadius: 'var(--radius-md)',
    border: '1px solid transparent',
    cursor: disabled ? 'not-allowed' : 'pointer',
    opacity: disabled ? 0.45 : 1,
    transition: 'background 120ms ease, color 120ms ease, border-color 120ms ease, transform 80ms ease',
    transform: active && !disabled ? 'scale(0.97)' : 'scale(1)',
    whiteSpace: 'nowrap',
    userSelect: 'none',
  };

  const variants = {
    primary: {
      background: hover ? 'var(--accent-gold-hover)' : 'var(--accent-gold)',
      color: 'var(--bg-base)',
    },
    secondary: {
      background: hover ? 'var(--bg-hover)' : 'var(--bg-elevated)',
      color: 'var(--text-primary)',
      borderColor: 'var(--border-default)',
    },
    ghost: {
      background: hover ? 'var(--bg-hover)' : 'transparent',
      color: 'var(--text-secondary)',
    },
    destructive: {
      background: hover ? 'rgba(239,68,68,0.18)' : 'rgba(239,68,68,0.12)',
      color: 'var(--status-red)',
      borderColor: 'rgba(239,68,68,0.4)',
    },
  };

  return (
    <button
      type={type}
      disabled={disabled}
      onClick={onClick}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => { setHover(false); setActive(false); }}
      onMouseDown={() => setActive(true)}
      onMouseUp={() => setActive(false)}
      style={{ ...base, ...(variants[variant] || variants.primary), ...style }}
      {...rest}
    >
      {iconLeft}
      {children}
      {iconRight}
    </button>
  );
}
