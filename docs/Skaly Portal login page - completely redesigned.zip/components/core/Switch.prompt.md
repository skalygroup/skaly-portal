Toggle switch — gold track when on. Used for attendance toggles, auto-renew, notification prefs.

```jsx
<Switch defaultChecked label="Auto-renew" />
<Switch checked={present} onChange={setPresent} />
```

Controlled (`checked`+`onChange`) or uncontrolled (`defaultChecked`). Knob slides with gold easing.
