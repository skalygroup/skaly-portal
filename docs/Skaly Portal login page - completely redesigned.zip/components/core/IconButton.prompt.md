Square icon-only button for topbars, toolbars, and row actions. Always pass a `label` for accessibility.

```jsx
<IconButton label="Search"><Search size={20} /></IconButton>
<IconButton label="Notifications" active><Bell size={20} /></IconButton>
<IconButton variant="outline" label="Filter"><SlidersHorizontal size={20} /></IconButton>
```

`active` turns the icon gold. Sizes 32/36/44px. Variants: `ghost` (default), `outline`.
