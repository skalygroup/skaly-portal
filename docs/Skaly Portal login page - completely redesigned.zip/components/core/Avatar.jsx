import React from 'react';

const PALETTE = [
  ['#FDC257', '#0D0D0F'],
  ['#3B82F6', '#F4F4F5'],
  ['#22C55E', '#0D0D0F'],
  ['#14B8A6', '#0D0D0F'],
  ['#F59E0B', '#0D0D0F'],
  ['#EF4444', '#F4F4F5'],
];

function initials(name = '') {
  return name.trim().split(/\s+/).slice(0, 2).map((w) => w[0] || '').join('').toUpperCase();
}

/** Avatar — image or initials fallback on a deterministic colour. */
export function Avatar({ name = '', src, size = 32, style = {} }) {
  const [broken, setBroken] = React.useState(false);
  const idx = name ? name.charCodeAt(0) % PALETTE.length : 0;
  const [bg, fg] = PALETTE[idx];

  const base = {
    width: size, height: size, flexShrink: 0,
    borderRadius: '50%',
    display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
    overflow: 'hidden',
    fontFamily: 'var(--font-body)', fontWeight: 600,
    fontSize: Math.max(10, Math.round(size * 0.4)),
    background: bg, color: fg,
    border: '1px solid rgba(255,255,255,0.08)',
    ...style,
  };

  if (src && !broken) {
    return <img src={src} alt={name} onError={() => setBroken(true)} style={{ ...base, objectFit: 'cover' }} />;
  }
  return <span style={base} aria-label={name}>{initials(name)}</span>;
}

/** Overlapping stack of avatars with optional +N overflow. */
export function AvatarStack({ people = [], size = 28, max = 4 }) {
  const shown = people.slice(0, max);
  const extra = people.length - shown.length;
  return (
    <div style={{ display: 'flex', alignItems: 'center' }}>
      {shown.map((p, i) => (
        <div key={i} style={{ marginLeft: i === 0 ? 0 : -size * 0.32, border: '2px solid var(--bg-elevated)', borderRadius: '50%' }}>
          <Avatar name={typeof p === 'string' ? p : p.name} src={typeof p === 'string' ? undefined : p.src} size={size} />
        </div>
      ))}
      {extra > 0 && (
        <div style={{
          marginLeft: -size * 0.32, width: size, height: size, borderRadius: '50%',
          display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
          background: 'var(--bg-hover)', color: 'var(--text-secondary)',
          border: '2px solid var(--bg-elevated)',
          fontFamily: 'var(--font-mono)', fontSize: Math.max(9, Math.round(size * 0.34)),
        }}>+{extra}</div>
      )}
    </div>
  );
}
