Checkbox — gold square with a dark check when on.

```jsx
<Checkbox label="Remember me" defaultChecked />
<Checkbox checked={all} onChange={toggleAll} label="Select all" />
```

Controlled or uncontrolled. Keyboard accessible (Space/Enter).
