Underline tabs. Active label and indicator are gold; tabs can show a count pill.

```jsx
<Tabs tabs={['All', 'Pending', 'Done']} defaultValue="All" onChange={setTab} />
<Tabs value={tab} onChange={setTab} tabs={[
  {value:'tasks',label:'Tasks',count:12},
  {value:'shoots',label:'Shoots',count:3},
]} />
```

Controlled or uncontrolled.
