Dark text field with gold focus ring. Use `mono` for data values (IDs, periods, numbers).

```jsx
<Input label="Email" type="email" placeholder="you@skaly.com" iconLeft={<Mail size={16} />} />
<Input label="Period" mono defaultValue="2025-06" />
<Input label="Name" error hint="This field is required" />
```

States: focus (gold border + dim glow), error (red), disabled. Pass `iconLeft` (Lucide 16px) and `hint`.
