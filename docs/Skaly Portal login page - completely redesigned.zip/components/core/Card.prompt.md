Elevated dark surface (`--bg-elevated`, 16px radius, subtle border). The base container for dashboards, panels, and forms.

```jsx
<Card title="Today's content" action={<IconButton label="More"><MoreHorizontal size={18}/></IconButton>}>
  …content…
</Card>
<Card padding={24} elevated>Floating panel</Card>
```

Header title uses Big Shoulders. Set `elevated` for a shadow, `padding` to control body inset.
