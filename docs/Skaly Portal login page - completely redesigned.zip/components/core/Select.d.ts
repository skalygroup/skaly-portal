import { CSSProperties, ChangeEventHandler } from 'react';

export interface SelectOption { value: string; label: string; }

export interface SelectProps {
  label?: string;
  value?: string;
  defaultValue?: string;
  /** Array of strings or {value,label}. */
  options?: (string | SelectOption)[];
  placeholder?: string;
  disabled?: boolean;
  mono?: boolean;
  onChange?: ChangeEventHandler<HTMLSelectElement>;
  id?: string;
  style?: CSSProperties;
}

/** Dark native select with gold focus ring and custom chevron. */
export function Select(props: SelectProps): JSX.Element;
