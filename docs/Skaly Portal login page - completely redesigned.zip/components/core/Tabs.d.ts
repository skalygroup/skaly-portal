import { CSSProperties } from 'react';

export interface TabItem { value: string; label: string; count?: number; }

export interface TabsProps {
  /** Strings or {value,label,count}. */
  tabs?: (string | TabItem)[];
  value?: string;
  defaultValue?: string;
  onChange?: (value: string) => void;
  style?: CSSProperties;
}

/** Underline tabs — active label + indicator are gold; optional count pill. */
export function Tabs(props: TabsProps): JSX.Element;
