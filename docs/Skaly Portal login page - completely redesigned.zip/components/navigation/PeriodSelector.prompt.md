Month/period selector that lives below the sidebar logo. Current month is gold (DM Mono); past months are grey. Drives the `?period=YYYY-MM` URL param.

```jsx
<PeriodSelector period="June 2025" onClick={openHistory} />
<PeriodSelector period="March 2025" isPast expanded />
```
