The portal's 220px left rail. Active item uses an **inset gold bar** (`inset 3px 0 0`) plus gold text — not a left border. Items take an icon, label, and optional count badge.

```jsx
<SidebarNav
  activeId="calendar"
  onSelect={setView}
  header={<Logo />}
  items={[
    { id:'home', label:'Home', icon:<Home size={20}/> },
    { id:'tasks', label:'Tasks', icon:<CheckSquare size={20}/>, badge:12 },
    { id:'calendar', label:'Content Calendar', icon:<Calendar size={20}/> },
  ]}
/>
```
