import { CSSProperties } from 'react';

export interface PeriodSelectorProps {
  /** Month label, e.g. "June 2025". Rendered in DM Mono. */
  period?: string;
  /** Past month → grey text instead of gold. */
  isPast?: boolean;
  /** Chevron points up when expanded. */
  expanded?: boolean;
  onClick?: () => void;
  style?: CSSProperties;
}

/** Month/period selector for the sidebar. Current = gold mono; past = grey. */
export function PeriodSelector(props: PeriodSelectorProps): JSX.Element;
