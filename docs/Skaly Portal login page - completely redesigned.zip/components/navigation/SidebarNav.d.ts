import { ReactNode, CSSProperties } from 'react';

export interface NavItemData {
  id: string;
  label: string;
  /** Lucide icon node (20px). */
  icon?: ReactNode;
  /** Optional count badge. */
  badge?: number | string;
}

export interface SidebarNavProps {
  items?: NavItemData[];
  activeId?: string;
  onSelect?: (id: string) => void;
  /** Logo / period selector block at top. */
  header?: ReactNode;
  /** User block at bottom. */
  footer?: ReactNode;
  /** @default 220 */
  width?: number;
  style?: CSSProperties;
}

/**
 * Portal left navigation rail. Active item = inset gold bar + gold text
 * (never a plain left border).
 *
 * @startingPoint section="Navigation" subtitle="Portal sidebar with gold active state" viewport="240x520"
 */
export function SidebarNav(props: SidebarNavProps): JSX.Element;
