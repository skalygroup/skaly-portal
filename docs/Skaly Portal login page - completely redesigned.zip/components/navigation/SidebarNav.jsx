import React from 'react';

/**
 * SidebarNav — the portal's left rail. Active item uses an inset gold bar
 * (NOT a left border) and gold text. Pass items with {id,label,icon,badge}.
 */
export function SidebarNav({ items = [], activeId, onSelect, header, footer, width = 220, style = {} }) {
  return (
    <nav style={{
      display: 'flex', flexDirection: 'column',
      width, height: '100%',
      background: 'var(--bg-surface)',
      borderRight: '1px solid var(--border-subtle)',
      ...style,
    }}>
      {header && <div style={{ padding: '16px 16px 8px' }}>{header}</div>}
      <div style={{ display: 'flex', flexDirection: 'column', gap: 2, padding: 8, flex: 1, overflowY: 'auto' }}>
        {items.map((it) => <NavItem key={it.id} item={it} active={it.id === activeId} onSelect={onSelect} />)}
      </div>
      {footer && <div style={{ padding: 12, borderTop: '1px solid var(--border-subtle)' }}>{footer}</div>}
    </nav>
  );
}

function NavItem({ item, active, onSelect }) {
  const [hover, setHover] = React.useState(false);
  return (
    <button
      type="button"
      onClick={() => onSelect && onSelect(item.id)}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      style={{
        position: 'relative',
        display: 'flex', alignItems: 'center', gap: 12,
        height: 40, padding: '0 12px', width: '100%',
        background: active ? 'var(--bg-selected)' : hover ? 'var(--bg-hover)' : 'transparent',
        boxShadow: active ? 'inset 3px 0 0 var(--accent-gold)' : 'none',
        border: 'none', borderRadius: 'var(--radius-sm)',
        cursor: 'pointer', textAlign: 'left',
        color: active ? 'var(--accent-gold)' : 'var(--text-secondary)',
        fontFamily: 'var(--font-body)', fontSize: 14, fontWeight: active ? 600 : 500,
        transition: 'background 120ms ease, color 120ms ease',
      }}
    >
      {item.icon && <span style={{ display: 'inline-flex', flexShrink: 0 }}>{item.icon}</span>}
      <span style={{ flex: 1, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{item.label}</span>
      {item.badge != null && (
        <span style={{
          fontFamily: 'var(--font-mono)', fontSize: 11, fontWeight: 600,
          minWidth: 18, height: 18, padding: '0 5px',
          display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
          borderRadius: 'var(--radius-full)',
          background: active ? 'var(--accent-gold-15)' : 'var(--bg-elevated)',
          color: active ? 'var(--accent-gold)' : 'var(--text-muted)',
        }}>{item.badge}</span>
      )}
    </button>
  );
}
