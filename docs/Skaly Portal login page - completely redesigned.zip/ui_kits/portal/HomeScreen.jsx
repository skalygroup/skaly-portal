/* Home (Manager view): stat row + today's content + upcoming shoots,
   with a right-hand activity feed. Quick actions open a Dialog. */
const DS_H = window.SkalyPortalDesignSystem_a5ef85;

const STATS = [
  { label: 'Team present', value: '11/13', tone: 'green' },
  { label: 'Tasks due today', value: '8', tone: 'gold' },
  { label: 'Shoots this week', value: '5', tone: 'gold' },
  { label: 'Posts pending', value: '3', tone: 'amber' },
];

const TODAY = [
  { client: 'Aurora Cafe', status: 'Posted' },
  { client: 'Lumen Realty', status: 'Ready' },
  { client: 'Verde Fitness', status: 'Under Progress' },
  { client: 'Nimbus Tech', status: 'Pending' },
  { client: 'Coral Salon', status: 'Blocked' },
];

const SHOOTS = [
  { client: 'Lumen Realty', when: 'Tue · 10:00', who: ['Sohail', 'Aman'] },
  { client: 'Verde Fitness', when: 'Wed · 14:30', who: ['Priya'] },
  { client: 'Aurora Cafe', when: 'Thu · 09:00', who: ['Sohail', 'Ravi', 'Aman'] },
];

const FEED = [
  { who: 'Sohail', what: 'marked Aurora Cafe reel as Posted', t: '14:32' },
  { who: 'Priya', what: 'uploaded 12 finals for Verde Fitness', t: '13:58' },
  { who: 'Aman', what: 'rescheduled Nimbus shoot to Fri', t: '11:20' },
  { who: 'Naaz', what: 'approved 3 signup requests', t: '10:05' },
  { who: 'Ravi', what: 'commented on Coral Salon pipeline', t: '09:41' },
];

function StatCard({ label, value, tone }) {
  const color = tone === 'green' ? 'var(--status-green)' : tone === 'amber' ? 'var(--status-amber)' : 'var(--accent-gold)';
  return (
    <div style={{ flex: 1, background: 'var(--bg-elevated)', border: '1px solid var(--border-subtle)', borderRadius: 'var(--radius)', padding: 18 }}>
      <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 40, lineHeight: 1, color }}>{value}</div>
      <div style={{ fontFamily: 'var(--font-body)', fontSize: 13, color: 'var(--text-muted)', marginTop: 6 }}>{label}</div>
    </div>
  );
}

function HomeScreen() {
  const { Icon } = window.PortalShell;
  const [dlg, setDlg] = React.useState(false);
  return (
    <div style={{ padding: 24, display: 'grid', gridTemplateColumns: '1fr 320px', gap: 20, alignItems: 'start' }}>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
        {/* greeting + quick actions */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <div>
            <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 28, color: 'var(--text-primary)' }}>Good morning, Naaz</div>
            <div style={{ fontFamily: 'var(--font-mono)', fontSize: 12, color: 'var(--text-muted)', marginTop: 2 }}>Friday · June 2025</div>
          </div>
          <div style={{ display: 'flex', gap: 10 }}>
            <DS_H.Button size="sm" iconLeft={<Icon name="plus" size={16} />} onClick={() => setDlg(true)}>New task</DS_H.Button>
            <DS_H.Button size="sm" variant="secondary" iconLeft={<Icon name="file-text" size={16} />}>Report</DS_H.Button>
          </div>
        </div>

        <div style={{ display: 'flex', gap: 14 }}>{STATS.map((s) => <StatCard key={s.label} {...s} />)}</div>

        <DS_H.Card title="Today's content">
          <div style={{ display: 'flex', flexDirection: 'column' }}>
            {TODAY.map((r, i) => (
              <div key={r.client} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', height: 44, borderTop: i ? '1px solid var(--border-subtle)' : 'none' }}>
                <span style={{ fontFamily: 'var(--font-body)', fontSize: 14, color: 'var(--text-primary)' }}>{r.client}</span>
                <DS_H.StatusChip status={r.status} />
              </div>
            ))}
          </div>
        </DS_H.Card>

        <DS_H.Card title="Upcoming shoots this week">
          <div style={{ display: 'flex', flexDirection: 'column' }}>
            {SHOOTS.map((r, i) => (
              <div key={r.client} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', height: 48, borderTop: i ? '1px solid var(--border-subtle)' : 'none' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                  <span style={{ color: 'var(--text-muted)' }}><Icon name="camera" size={16} /></span>
                  <span style={{ fontFamily: 'var(--font-body)', fontSize: 14, color: 'var(--text-primary)' }}>{r.client}</span>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
                  <span style={{ fontFamily: 'var(--font-mono)', fontSize: 12, color: 'var(--text-secondary)' }}>{r.when}</span>
                  <DS_H.AvatarStack people={r.who} size={26} />
                </div>
              </div>
            ))}
          </div>
        </DS_H.Card>
      </div>

      {/* activity feed */}
      <DS_H.Card title="Activity">
        <div style={{ display: 'flex', flexDirection: 'column', gap: 0 }}>
          {FEED.map((f, i) => (
            <div key={i} style={{ display: 'flex', gap: 10, padding: '10px 0', borderTop: i ? '1px solid var(--border-subtle)' : 'none' }}>
              <DS_H.Avatar name={f.who} size={28} />
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontFamily: 'var(--font-body)', fontSize: 13, color: 'var(--text-secondary)', lineHeight: 1.4 }}>
                  <b style={{ color: 'var(--text-primary)', fontWeight: 600 }}>{f.who}</b> {f.what}
                </div>
                <div style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--text-muted)', marginTop: 2 }}>{f.t}</div>
              </div>
            </div>
          ))}
        </div>
      </DS_H.Card>

      <DS_H.Dialog open={dlg} title="New task" onClose={() => setDlg(false)}
        footer={<>
          <DS_H.Button variant="secondary" onClick={() => setDlg(false)}>Cancel</DS_H.Button>
          <DS_H.Button onClick={() => setDlg(false)}>Create task</DS_H.Button>
        </>}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          <DS_H.Input label="Description" placeholder="Edit Aurora Cafe reel" />
          <div style={{ display: 'flex', gap: 12 }}>
            <DS_H.Select label="Client" options={['Aurora Cafe', 'Lumen Realty', 'Verde Fitness']} />
            <DS_H.Input label="Deadline" mono placeholder="2025-06-09" />
          </div>
        </div>
      </DS_H.Dialog>
    </div>
  );
}
window.HomeScreen = HomeScreen;
