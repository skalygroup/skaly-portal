/* Content Calendar — the signature grid. Sticky date column, client columns,
   today-row tint, gold column highlight on active cell, click-to-edit popover. */
const DS_C = window.SkalyPortalDesignSystem_a5ef85;

const CLIENTS = ['Aurora Cafe', 'Lumen Realty', 'Verde Fitness', 'Nimbus Tech', 'Coral Salon', 'Orbit Media'];
const STATUS_CYCLE = ['', 'To Do', 'Under Progress', 'Ready', 'Posted', 'Blocked'];

function seedGrid() {
  const days = [];
  const pool = ['', '', 'Posted', 'Ready', 'Under Progress', 'To Do', 'Pending', 'Blocked', 'Done'];
  for (let d = 1; d <= 14; d++) {
    const row = CLIENTS.map((c, ci) => pool[(d * 3 + ci * 5) % pool.length]);
    days.push({ d, row });
  }
  return days;
}

function CalendarScreen() {
  const { Icon } = window.PortalShell;
  const [grid, setGrid] = React.useState(seedGrid);
  const [active, setActive] = React.useState(null);       // {d, ci}
  const [editing, setEditing] = React.useState(null);     // {d, ci, x, y}
  const TODAY = 6;

  const setCell = (d, ci, status) => {
    setGrid((g) => g.map((r) => r.d === d ? { ...r, row: r.row.map((s, i) => i === ci ? status : s) } : r));
  };

  return (
    <div style={{ padding: 24, height: '100%', boxSizing: 'border-box', display: 'flex', flexDirection: 'column', gap: 14 }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <DS_C.Tabs tabs={['Calendar', 'Pipeline']} defaultValue="Calendar" />
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <span style={{ fontFamily: 'var(--font-mono)', fontSize: 12, color: 'var(--text-muted)' }}>{CLIENTS.length} clients · June 2025</span>
          <DS_C.Button size="sm" variant="secondary" iconLeft={<Icon name="sliders-horizontal" size={16} />}>Filter</DS_C.Button>
        </div>
      </div>

      <div style={{ flex: 1, overflow: 'auto', border: '1px solid var(--border-subtle)', borderRadius: 'var(--radius)', background: 'var(--bg-surface)', position: 'relative' }}>
        <table style={{ borderCollapse: 'collapse', width: '100%', minWidth: 720 }}>
          <thead>
            <tr>
              <th style={{ position: 'sticky', left: 0, top: 0, zIndex: 3, width: 80, background: 'var(--bg-elevated)', borderBottom: '1px solid var(--border-default)', borderRight: '1px solid var(--border-default)', padding: '10px 12px', textAlign: 'left' }}>
                <span style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '.06em' }}>Date</span>
              </th>
              {CLIENTS.map((c, ci) => (
                <th key={c} style={{ position: 'sticky', top: 0, zIndex: 2, minWidth: 110, background: 'var(--bg-elevated)', borderBottom: '1px solid var(--border-default)', borderRight: '1px solid var(--border-subtle)', padding: '10px 12px', textAlign: 'left' }}>
                  <span style={{ fontFamily: 'var(--font-body)', fontSize: 13, fontWeight: 600, color: active && active.ci === ci ? 'var(--accent-gold)' : 'var(--text-primary)', whiteSpace: 'nowrap' }}>{c}</span>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {grid.map(({ d, row }) => {
              const isToday = d === TODAY;
              return (
                <tr key={d} style={{ background: isToday ? 'var(--accent-gold-06)' : 'transparent' }}>
                  <td style={{ position: 'sticky', left: 0, zIndex: 1, background: isToday ? '#181510' : 'var(--bg-surface)', borderRight: '1px solid var(--border-default)', borderBottom: '1px solid var(--border-subtle)', padding: '0 12px', height: 48 }}>
                    <span style={{ fontFamily: 'var(--font-mono)', fontSize: 13, color: isToday ? 'var(--accent-gold)' : 'var(--text-secondary)' }}>{String(d).padStart(2, '0')} Jun</span>
                  </td>
                  {row.map((status, ci) => {
                    const isActive = active && active.d === d && active.ci === ci;
                    const colActive = active && active.ci === ci;
                    return (
                      <td key={ci}
                        onClick={(e) => {
                          const r = e.currentTarget.getBoundingClientRect();
                          const host = e.currentTarget.closest('[data-cal-host]').getBoundingClientRect();
                          setActive({ d, ci });
                          setEditing({ d, ci, x: r.left - host.left, y: r.top - host.top + 50 });
                        }}
                        style={{
                          height: 48, padding: '0 10px', cursor: 'pointer',
                          borderRight: '1px solid var(--border-subtle)', borderBottom: '1px solid var(--border-subtle)',
                          background: isActive ? 'var(--accent-gold-dim)' : colActive ? 'rgba(253,194,87,0.04)' : 'transparent',
                          boxShadow: isActive ? 'inset 1px 0 0 var(--accent-gold-border), inset -1px 0 0 var(--accent-gold-border)' : 'none',
                          transition: 'background 80ms ease',
                        }}>
                        {status ? <DS_C.StatusChip status={status} trigger={status === 'Posted' && ci % 2 === 0} /> : <span style={{ color: 'var(--text-disabled)', fontFamily: 'var(--font-mono)', fontSize: 13 }}>—</span>}
                      </td>
                    );
                  })}
                </tr>
              );
            })}
          </tbody>
        </table>

        {/* host marker for popover positioning */}
        <div data-cal-host style={{ position: 'absolute', inset: 0, pointerEvents: 'none' }} />

        {editing && (
          <>
            <div onClick={() => { setEditing(null); setActive(null); }} style={{ position: 'fixed', inset: 0, zIndex: 40 }} />
            <div style={{
              position: 'absolute', left: Math.min(editing.x, 560), top: editing.y, zIndex: 50, width: 220,
              background: 'var(--bg-elevated)', border: '1px solid var(--border-default)', borderRadius: 'var(--radius-md)',
              boxShadow: 'var(--shadow-lg)', padding: 12, display: 'flex', flexDirection: 'column', gap: 10,
            }}>
              <div style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--text-muted)' }}>{CLIENTS[editing.ci]} · {String(editing.d).padStart(2, '0')} Jun</div>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
                {STATUS_CYCLE.filter(Boolean).map((s) => (
                  <span key={s} onClick={() => { setCell(editing.d, editing.ci, s); setEditing(null); setActive(null); }} style={{ cursor: 'pointer' }}>
                    <DS_C.StatusChip status={s} />
                  </span>
                ))}
              </div>
              <textarea placeholder="Add note…" style={{
                width: '100%', boxSizing: 'border-box', minHeight: 52, resize: 'none',
                background: 'var(--bg-base)', border: '1px solid var(--border-default)', borderRadius: 'var(--radius-sm)',
                color: 'var(--text-primary)', fontFamily: 'var(--font-body)', fontSize: 13, padding: 8, outline: 'none',
              }} />
            </div>
          </>
        )}
      </div>
      <div style={{ fontFamily: 'var(--font-body)', fontSize: 12, color: 'var(--text-muted)', display: 'flex', alignItems: 'center', gap: 8 }}>
        <span style={{ width: 6, height: 6, borderRadius: '50%', background: 'var(--accent-gold)' }} /> gold dot = auto-updated from Content Dropper · click a cell to edit
      </div>
    </div>
  );
}
window.CalendarScreen = CalendarScreen;
