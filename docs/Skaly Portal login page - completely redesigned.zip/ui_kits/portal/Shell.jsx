/* Portal shell: Icon helper, Sidebar, Topbar, and the app frame.
   Composes SidebarNav / PeriodSelector / IconButton / Badge from the bundle. */
const DS = window.SkalyPortalDesignSystem_a5ef85;

/* ---- Lucide icon (vanilla createIcons into a ref) ---- */
function Icon({ name, size = 20, color }) {
  const ref = React.useRef(null);
  React.useEffect(() => {
    if (!ref.current || !window.lucide) return;
    ref.current.innerHTML = `<i data-lucide="${name}"></i>`;
    window.lucide.createIcons({ attrs: { width: size, height: size, stroke: color || 'currentColor' } });
  }, [name, size, color]);
  return <span ref={ref} style={{ display: 'inline-flex', alignItems: 'center' }} />;
}

const NAV = [
  { id: 'home', label: 'Home', icon: 'house' },
  { id: 'attendance', label: 'Attendance', icon: 'user-check' },
  { id: 'tasks', label: 'Tasks', icon: 'square-check-big', badge: 12 },
  { id: 'planner', label: 'Shoot Planner', icon: 'camera' },
  { id: 'dropper', label: 'Content Dropper', icon: 'upload' },
  { id: 'calendar', label: 'Content Calendar', icon: 'calendar' },
  { id: 'chat', label: 'Common Chat', icon: 'message-square', badge: 3 },
  { id: 'bot', label: 'AI Bot', icon: 'sparkles' },
];

function Logo() {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
        <img src="../../assets/skaly-mark.svg" width="26" height="26" alt="" style={{ borderRadius: 7 }} />
        <span style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 18, letterSpacing: '.04em', color: 'var(--accent-gold)' }}>SKALY</span>
      </div>
      <DS.PeriodSelector period="June 2025" onClick={() => {}} />
    </div>
  );
}

function Sidebar({ active, onSelect, user }) {
  const items = NAV.map((n) => ({ ...n, icon: <Icon name={n.icon} size={20} /> }));
  return (
    <DS.SidebarNav
      items={items}
      activeId={active}
      onSelect={onSelect}
      header={<Logo />}
      footer={
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <DS.Avatar name={user.name} size={32} />
          <div style={{ lineHeight: 1.3, minWidth: 0 }}>
            <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--text-primary)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{user.name}</div>
            <div style={{ fontSize: 11, color: 'var(--text-muted)' }}>{user.role}</div>
          </div>
        </div>
      }
    />
  );
}

function Topbar({ title, onSearch, onLogout }) {
  return (
    <header style={{
      height: 56, flexShrink: 0,
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      padding: '0 20px',
      background: 'var(--bg-surface)',
      borderBottom: '1px solid var(--border-subtle)',
    }}>
      <h1 style={{ margin: 0, fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 24, color: 'var(--text-primary)' }}>{title}</h1>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
        <button onClick={onSearch} style={{
          display: 'flex', alignItems: 'center', gap: 8, height: 36, padding: '0 10px 0 12px',
          background: 'var(--bg-elevated)', border: '1px solid var(--border-default)',
          borderRadius: 'var(--radius-md)', cursor: 'pointer', color: 'var(--text-muted)',
        }}>
          <Icon name="search" size={16} />
          <span style={{ fontFamily: 'var(--font-body)', fontSize: 13 }}>Search…</span>
          <span style={{ fontFamily: 'var(--font-mono)', fontSize: 11, padding: '1px 5px', borderRadius: 4, background: 'var(--bg-hover)', color: 'var(--text-secondary)' }}>⌘K</span>
        </button>
        <div style={{ position: 'relative' }}>
          <DS.IconButton label="Notifications"><Icon name="bell" size={20} /></DS.IconButton>
          <span style={{ position: 'absolute', top: 2, right: 2, width: 8, height: 8, borderRadius: '50%', background: 'var(--accent-gold)', border: '2px solid var(--bg-surface)' }} />
        </div>
        <DS.IconButton label="Sign out" onClick={onLogout}><Icon name="log-out" size={20} /></DS.IconButton>
      </div>
    </header>
  );
}

window.PortalShell = { Icon, Sidebar, Topbar, NAV };
