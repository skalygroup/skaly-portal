/* Login screen — dark, centred, gold CTA. Google sign-in + MFA hint. */
const DS_L = window.SkalyPortalDesignSystem_a5ef85;

function LoginScreen({ onLogin }) {
  const { Icon } = window.PortalShell;
  const [email, setEmail] = React.useState('naaz@skalygroup.com');
  const [pw, setPw] = React.useState('••••••••••');
  return (
    <div style={{
      minHeight: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center',
      background: 'radial-gradient(120% 90% at 50% 0%, #161318 0%, var(--bg-base) 60%)',
      padding: 24,
    }}>
      <div style={{ width: 380 }}>
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 14, marginBottom: 28 }}>
          <img src="../../assets/skaly-mark.svg" width="52" height="52" alt="Skaly" style={{ borderRadius: 14 }} />
          <div style={{ textAlign: 'center' }}>
            <div style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 30, color: 'var(--text-primary)', lineHeight: 1.1 }}>Welcome back</div>
            <div style={{ fontFamily: 'var(--font-body)', fontSize: 14, color: 'var(--text-muted)', marginTop: 4 }}>Sign in to the Skaly Business Portal</div>
          </div>
        </div>
        <div style={{
          background: 'var(--bg-elevated)', border: '1px solid var(--border-subtle)',
          borderRadius: 'var(--radius)', padding: 24, display: 'flex', flexDirection: 'column', gap: 16,
        }}>
          <DS_L.Input label="Email" value={email} onChange={(e) => setEmail(e.target.value)} iconLeft={<Icon name="mail" size={16} />} />
          <DS_L.Input label="Password" type="password" value={pw} onChange={(e) => setPw(e.target.value)} iconLeft={<Icon name="lock" size={16} />} />
          <DS_L.Button fullWidth onClick={onLogin}>Sign in</DS_L.Button>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12, color: 'var(--text-disabled)' }}>
            <span style={{ flex: 1, height: 1, background: 'var(--border-subtle)' }} />
            <span style={{ fontFamily: 'var(--font-mono)', fontSize: 11 }}>OR</span>
            <span style={{ flex: 1, height: 1, background: 'var(--border-subtle)' }} />
          </div>
          <DS_L.Button variant="secondary" fullWidth iconLeft={<Icon name="chrome" size={16} />} onClick={onLogin}>Continue with Google</DS_L.Button>
        </div>
        <div style={{ textAlign: 'center', marginTop: 18, fontFamily: 'var(--font-body)', fontSize: 13, color: 'var(--text-muted)' }}>
          No account? <span style={{ color: 'var(--accent-gold)', cursor: 'pointer' }}>Request access</span>
        </div>
      </div>
    </div>
  );
}
window.LoginScreen = LoginScreen;
